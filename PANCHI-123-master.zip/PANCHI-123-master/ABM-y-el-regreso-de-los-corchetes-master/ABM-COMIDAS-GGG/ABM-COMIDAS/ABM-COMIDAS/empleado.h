#ifndef empleado_H_INCLUIDA//Para evitar que el compilador tire error por incluir varias veces la misma biblioteca del usuario.
#define empleado_H_INCLUIDA
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <conio.h>
#include <ctype.h>

typedef struct
{
    int dia;
    int mes;
    int anio;
} eFecha;



typedef struct
{
    int legajo;
    char apellido[51];
    char nombre[51];
    char sexo;
    float sueldo;
    eFecha fechaIn;
    int idSector;
    int isEmpty;

} eEmpleado;

typedef struct // tipo de dato tipificado.
{
    int id;
    char desc[20];
} eSector;



typedef struct // tipo de dato tipificado.
{
    int id;
    int idMenu;
    int legajoEmp;
    eFecha fechaAlmuerzo;

    int isEmpty;
} eAlmuerzo;



typedef struct // tipo de dato tipificado.
{
    int id;
    char desc[51];
    float importe;
} eMenu;



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////



/** \brief Function: Muestra el menu por pantalla y captura la opcion seleccionada.
*   \param Request: NULL.
*   \return Returns: Opcion elegida.
*/
int menu();


/** \brief Function: Muestra el sub menu por pantalla y captura la opcion seleccionada.
*   \param Request: NULL.
*   \return Returns: Opcion elegida.
*/
int subMenu();


/** \brief Function: Inicializa la estructura seleccionada en 0.
*   \param Request: Array vec de la estructura eEmpleado.
*   \param Request: Int tama�o maximo de la estructura eEmpleado.
*   \return Returns: NULL.
*/
void inicializarEmpleados(eEmpleado vec[], int tam);

/** \brief Function: Inicializa y copia lo que esta hardcodeado en los vec de las estructuras correspondientes.
 *
 * \param Request: Array vec de la estructura de eEmpleado.
 * \param Request: Int tam tama�o maximo de la estructura eEmpleado.
 * \param Request: Array sectores de la estructura eSector.
 * \param Request: Int tamSectores tama�o maximo de la estructura eSector.
 * \param Request: Array menu de la estructura eMenu.
 * \param Request: Int tamMenu tama�o maximo de la estructura eMenu.
 * \param Request: Array vecAlmuerzo de la estructura eAlmuerzo.
 * \param Request: Int tamAlmuerzo tama�o maximo de la estructura eAlmuerzo.
 * \return Returns: NULL.
 *
 */
void inicializacion(eEmpleado vec[], int tam, eSector sectores[], int tamSectores, eMenu menu[], int tamMenu,eAlmuerzo vecAlmuerzo[],int tamAlmuerzo);


/** \brief Function: Obtiene el primer indice libre del array vec de la estructura eEmpleado.
 *  \param Request: Array vec de la estructura eEmpleado.
 *  \param Request: Int tam tama�o maximo de la estructura eEmpleado.
 * \return Returns: Si no hay ocurrencia (-1) y si la hay, la posici�n de la misma.
 *
 */
int buscarLibre(eEmpleado vec[], int tam);


/** \brief Function: Obtiene el indice que coincide con el ID pasado por parametro.
 *  \param Request: Array vec de la estructura eEmpleado.
 *  \param Request: Int valor maximo de la estructura eEmpleado.
 *  \param Request: Int ID a ser buscado en el array de la estructura eEmpleado.
 *  \return Returns: el indice en donde se encuentra el elemento que coincide con el parametro ID o (-1) si no lo encuentra.
 */
int buscarEmpleado(eEmpleado vec[], int tam, int legajo);
/** \brief Function: Compara si el id sector empleado(eEmpleado) es igual al id de sector(eSector) y copia la descripcion.
 *
 * \param Request: Array sectores de la estructura eSector.
 * \param Request: Int tamSectores tama�o maximo de la estructura eSector.
 * \param Request: Int idSectorEmp es un elemento entero para comparar con el elemento id de la estructura eSector.
 * \param Request: Char descMostrar es un array donde se copiara la descripcion de el elemento desc de la estructura eSector.
 * \return Returns: NULL.
 *
 */
void obtenerSector(eSector sectores[], int tamSectores, int idSectorEmp, char descMostrar[]);
/** \brief Function: Asigna datos validados a un empleado incremental dentro del array vec
 *
 * \param Request: Array vec de la estructura eEmpleado.
 * \param Request: Int tam valor maximo de la estructura eEmpleado.
 * \param Request: Array sec de la estructura eSector.
 * \param Request: Int tamSectores valor maximo de la estructura eSector.
 * \param Request: Int legajoMain valor autoincremental de la funcion Main.
 * \return Returns: Int altaOk (1) si se logro hacer el alta o (0) si no se logro el alta.
 *
 */
int altaEmpleado(eEmpleado vec[], int tam,eSector sec[],int tamSectores, int legajoMain);

/** \brief Function: Asigna a un empleado incremental dentro del array vec.isEmpty(-1).
 *
 * \param Request: Array vec de la estructura eEmpleado.
 * \param Request: Int tam valor maximo de la estructura eEmpleado.
 * \return Returns: NULL.
 *
 */
void bajaEmpleado(eEmpleado vec[], int tam,eSector sec[],int tamSec);
/** \brief Function: Modifica datos validados a un empleado elegido dentro del array vec
 *
 * \param Request: Array vec de la estructura eEmpleado.
 * \param Function: Int tam valor maximo de la estructura eEmpleado.
 * \param Request: Array sec de la estructura eSector.
 * \param Request: Int tamSectores valor maximo de la estructura eSector.
 * \return Returns: NULL.
 *
 */
void modificarEmpleado(eEmpleado vec[], int tam,eSector vecSec[],int tamSectores);

/** \brief Function: muestra un empleado si este esta dado de alta.
 *
 * \param Request: Array sectores de la estructura eSector.
 * \param Request: Int tamSectores valor maximo de laestructura eSector.
 * \param Request: Array emp de la estructura eEmpleado.
 * \param Request: Int i indice de la estructura eEmpleado.
 * \return Returns: NULL.
 *
 */
void mostrarEmpleado(eSector sectores[],int tamSectores,eEmpleado emp[], int i);

/** \brief Function: muestra todos los empleados que esten dados de alta.
 * \param Request: Array sectores de la estructura eSector.
 * \param Request: Int tamSectores valor maximo de laestructura eSector.
 * \param Request: Array vec de la estructura eEmpleado.
 * \param Request: Int tam tama�o maximo de la estructura eEmpleado.
 * \return Returns: NULL.
 *
 */

void mostrarEmpleados(eSector sectores[], int tamSectores, eEmpleado vec[], int tam);

/** \brief Function: Ordena los nombres de A-Z.
 *  \param  Request: Array vec de la estructura eEmpleado.
 *  \param  Request: Int tam el tama�o maximo de la estructura eEmpleado.
 *  \return Returns: NULL.
 */
void ordenarEmpleadosApellido(eEmpleado vec[], int tam);

/** \brief Function: Muestra un empleado y su sector si existe y si sus ids son iguales.
 *
 * \param Request: Array vec de la estructura eEmpleado.
 * \param Request: Int tam tama�o maximo de la estructura eEmpleado.
 * \param Request: Array sec de la estructura eSector.
 * \param Request: Int tamSec tama�o maximo de la estructura eSector.
 * \return
 *
 */
void mostrarSector (eEmpleado vec[], int tam, eSector sec[], int tamSec);
/** \brief Function: Inicializa la estructura seleccionada en 0.
*   \param Request: Array vec de la estructura vec.
*   \param Request: Int tam el tama�o maximo de la estructura eEmpleado.
*   \return Returns: NULL.
*/
void inicializarAlmuerzos(eAlmuerzo vec[], int tamAlmuerzo);

/** \brief Function: Obtiene el primer indice libre del array vec de la estructura eAlmuerzo.
 *  \param Request: Array vec de la estructura eAlmuerzo.
 *  \param Request: Int tamAlmuerzo tama�o maximo de la estructura eAlmuerzo.
 * \return Returns: Si no hay ocurrencia (-1) y si la hay, la posici�n de la misma.
 *
 */
 int buscarLibreAlmuerzo(eAlmuerzo vec[], int tamAlmuerzo);
/** \brief Function: Obtiene el indice que coincide con el ID pasado por parametro.
 *  \param Request: Array vec de la estructura eAlmuerzo.
 *  \param Request:  Int tamAlmuerzo tama�o maximo de la estructura eAlmuerzo.
 *  \param Request:  Int id numero a ser buscado en el array.
 *  \return Returns: Int indice, el indice en donde se encuentra el elemento que coincide con el parametro ID o (-1) si no lo encuentra.
 */
int buscarAlmuerzo(eAlmuerzo vec[], int tamAlmuerzo, int id);


/** \brief Function: Asigna datos validados a un empleado incremental dentro del array vec.
 *
 * \param Request: Array vecAlmuerzo de la estructura eAlmuerzo.
 * \param Request: Int tamAlmuerzo tama�o maximo de la estructura eAlmuerzo.
 * \param Request: Array vecEmpleado de la estructura eEmpleado.
 * \param Request: Int tam valor maximo de la estructura eEmpleado.
 * \param Request: Array sec de la estructura eSector.
 * \param Request: Int tamSectores valor maximo de la estructura eSector.
 * \param Request: Int legajoMain valor autoincremental de la funcion Main.
 * \param Request: Array vecMenu de la estructura eMenu.
 * \param Request: Int tamMenu valor maximo de la estructura eMenu.
 * \return Returns: Int altaOk (1) si se logro hacer el alta o (0) si no se logro el alta.
 *
 */
int altaAlmuerzo(eAlmuerzo vecAlmuerzo[],int tamAlmuerzo,eEmpleado vecEmpleado[], int tam,eSector sec[],int tamSectores, int legajoMain,eMenu vecMenu[],int tamMenu);
/** \brief Function: muestra un almuerzo si este esta dado de alta.
 *
 * \param Request: Array alm de la estructura eAlmuerzo.
 * \param Request: Int i indice de la estructura eAlmuerzo.
 * \return Returns: NULL.
 *
 */
void mostrarAlmuerzo(eAlmuerzo alm[],int i);


/** \brief Function: muestra todos los almuerzos si estan dados de alta.
 *
 * \param Request: Array vecAlmuerzo de la estructura eAlmuerzo.
 * \param Request: Int tamAlmuerzo tama�o maximo de la estructura eAlmuerzo.
 * \return Returns: NULL.
 *
 */
void mostrarAlmuerzos(eAlmuerzo vecAlmuerzo[], int tamAlmuerzo);

/////////////////////////////////////////////////////////////////////////////////////////////////////////

/** \brief Function: Muestra todos los almuerzo de un empleado seleccionado.
 *
 * \param Request: Array vec de la estructura eEmpleado.
 * \param Request: Int tam tama�o maximo de la estructura eEmpleado.
 * \param Request: Array vecSectores de la estructura eSector.
 * \param Request: Int tamSectores tama�o maximo de la estructura eSector.
 * \param Request: Array vecAlmuerzo de la estructura eAlmuerzo.
 * \param Request: Int tamAlmuerzos tama�o maximo de la estructura eAlmuerzo.
 * \return Returns: NULL.
 *
 */
void mostrarAlmuerzosDeUnEmpleado(eEmpleado vec[],int tam,eSector vecSectores[],int tamSectores,eAlmuerzo vecAlmuerzos[],int tamAlmuerzos);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/** \brief Function: Muestra todos los elementos de  vecMenu de la estructura eMenu.
 *
 * \param Request: Array vecMenu de la estructura eMenu.
 * \param Request: Int tamMenu tama�o maximo de la estructura eMenu.
 * \return Returns: NULL.
 *
 */
void mostrarMenu(eMenu vecMenu[], int tamMenu);

/** \brief Function: Muestra el menu de informes por pantalla y captura la opcion seleccionada.
*   \param Request: NULL.
*   \return Returns: Opcion elegida.
*/
int menuDeInformes();
/** \brief Functon: Muestra la cantidad de empleados que estan dados de alta.
 * \param Request: Array vec de la estructura eEmpleado.
 * \param Request: Int tam tama�o maximo de la estructura eEmpleado.
 * \return Returns: Int contador (cantidad de empleados dados de alta).
 *
 */
int empleadosDadosDeAlta(eEmpleado vec[],int tam);
/** \brief Function: Ordena la estructura eEmpleado segun su elemento (sueldo).
 *
 * \param  Request: Array vec de la estructura eEmpleado.
 * \param Request: Int tam tama�o maximo de la estructura eEmpleado.
 * \return Returns: NULL.
 *
 */
void ordenarEmpleadosPorSueldo(eEmpleado vec[],int tam);

/** \brief Function: Muestra la cantidad de empleados que posee un sector seleccionado.
 *
 * \param Request: Array vec de la estructura eEmpleado.
 * \param Request: Int tam tama�o maximo de la estructura eEmpleado.
 * \return Returns: Int contador (cantidad de empleados en un sector);
 *
 */
int cuantosEmpleadosTieneEsteSector(eEmpleado vec[],int tam);
/** \brief Function: Muestra la suma de todos los almuerzos dados de alta.
 *
 * \param Request: Array vecAlmuerzo de la estructura eAlmuerzo.
 * \param Request: Int tamAlmuerzo tama�o maximo de la estructura eAlmuerzo.
 * \param Request: Array vecMenu de la estructura eMenu.
 * \param Request: Int tamMenu tama�o maximo de la estructura eMenu.
 * \return Returns: Float acumulador (suma de todos los almuerzos dados de alta).
 *
 */
int recaudacionAlmuerzos(eAlmuerzo vecAlmuerzo[],int tamAlmuerzo,eMenu vecMenu[],int tamMenu);

#endif
