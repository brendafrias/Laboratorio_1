#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>



#include "input.h"
#include "empleado.h"


#define TAM_EMP 20
#define TAM_SEC 5
#define TAM_MENU 10
#define TAM_ALMUERZOS 200




int main()
{

    char seguir = 's';
    char confirma;
    int banderaAlta;
    int legajoIncremental=10;

    int banderaAlta2;
    int legajoIncremental2=3;

    int auxLegajo;

    eEmpleado vecEmpleado[TAM_EMP];
    eSector vecSector[TAM_SEC];
    eMenu vecMenu[TAM_MENU];
    eAlmuerzo vecAlmuerzo[TAM_ALMUERZOS];



    int opcionMenuInformes;
    int cantidadEmpleadosDadosAlta;
    int cantidadEmpleadosSectorSeleccionado;
    float auxRecaudacion;



         inicializacion(vecEmpleado,TAM_EMP,vecSector,TAM_SEC,vecMenu,TAM_MENU,vecAlmuerzo,TAM_ALMUERZOS);


     do
    {
        switch(menu())
        {

        case 1:

            banderaAlta=(altaEmpleado(vecEmpleado, TAM_EMP, vecSector, TAM_SEC, legajoIncremental));
            system("pause");

            if(banderaAlta==1){
                legajoIncremental++;
            }

            break;

        case 2:
            bajaEmpleado(vecEmpleado,TAM_EMP,vecSector,TAM_SEC);
            system("pause");
            break;

        case 3:
            modificarEmpleado(vecEmpleado,TAM_EMP,vecSector,TAM_SEC);
            system("pause");
            break;

        case 4:
            printf("listar empleados ordenados alfabeticamente");
            ordenarEmpleadosApellido(vecEmpleado,TAM_EMP);
            mostrarEmpleados(vecSector,TAM_SEC,vecEmpleado,TAM_EMP);
            system("pause");
            break;

        case 5:

            printf("ALTA ALMUERZO \n");
            banderaAlta2=altaAlmuerzo(vecAlmuerzo,TAM_ALMUERZOS,vecEmpleado,TAM_EMP,vecSector,TAM_SEC,legajoIncremental2,vecMenu,TAM_MENU);


            if(banderaAlta2==1){
                legajoIncremental2++;
            }

            break;


        case 6:
            printf("mostrar almuerzos");

            mostrarAlmuerzos(vecAlmuerzo,TAM_ALMUERZOS);


            system("pause");
            break;




        case 7:
            printf("\nMuestra todos los almuerzos de un empleado\n");
            mostrarAlmuerzosDeUnEmpleado(vecEmpleado,TAM_EMP,vecSector,TAM_SEC,vecAlmuerzo,TAM_ALMUERZOS);
                break;

        case 8:
                printf("\nMenu de informes\n");
                opcionMenuInformes=menuDeInformes();


                switch(opcionMenuInformes)
                {
                    case 1:
                        printf("\nMostrar que cantidad hay de empleados\n");
                        cantidadEmpleadosDadosAlta=empleadosDadosDeAlta(vecEmpleado,TAM_EMP);
                        printf("\nla cantidad de empleados actual es:%d",cantidadEmpleadosDadosAlta);

                        break;

                    case 2:
                        printf("2- Mostrar empleados por sueldo mas alto\n");
                        ordenarEmpleadosPorSueldo(vecEmpleado,TAM_EMP);
                        mostrarEmpleados(vecSector,TAM_SEC,vecEmpleado,TAM_EMP);

                        break;

                    case 3:
                        printf("3- Seleccionar un sector y mostrar cuantos empleados tiene\n");
                        cantidadEmpleadosSectorSeleccionado=cuantosEmpleadosTieneEsteSector(vecEmpleado,TAM_EMP);
                        printf("\n la cantidad de empleados en ese sector es:%d",cantidadEmpleadosSectorSeleccionado);

                        break;

                    case 4:
                        printf("4- Mostrar la recaudacion de almuerzos\n");
                        auxRecaudacion=recaudacionAlmuerzos(vecAlmuerzo,TAM_ALMUERZOS,vecMenu,TAM_MENU);
                        printf("\n la recaudacion de los almuerzos es: %.2f",auxRecaudacion);

                        break;

                    case 5:
                            printf("5- Mostrar el menu mas pedido\n");

                            break;

                    case 6:
                        printf("6-Saliendo\n");
                        break;

                }



        case 9:
            printf("\nConfirma la salida del programa s/n?: ");
            fflush(stdin);
            confirma = getche();

            if( tolower(confirma) == 's')
            {
                printf("\n\n-- Programa finalizado --\n");
                seguir = 'n';
            }
            break;


        default:
            printf("\n Opcion invalida\n\n");
            system("pause");
            break;
        }
    }
    while(seguir == 's');

    return 0;

}
