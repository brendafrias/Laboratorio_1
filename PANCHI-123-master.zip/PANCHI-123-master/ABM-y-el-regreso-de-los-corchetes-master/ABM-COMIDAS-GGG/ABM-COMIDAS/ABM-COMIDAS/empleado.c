#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>


#include "input.h"
#include "empleado.h"




///////////////////////////////////////////////////////////////////////////////////////////////////////
int menu()
{


    int opcion;
    printf("\n1- Alta Empleado\n");
    printf("2- Baja Empleado\n");
    printf("3- Modificar Empleado\n");
    printf("4- Listar empleados ordenados alfabeticamente\n");
    printf("5- Alta Almuerzos\n");
    printf("6- Listar Almuerzos Por Empleados\n");
    printf("7- Mostrar todos los almuerzos de un empleado\n");
    printf("8- Ingresa al sub menu de informes\n");
    printf("9- salir\n");

    fflush(stdin);
    printf("\nIngrese una opcion: ");
    scanf("%d",&opcion);

    return opcion;

}
//////////////////////////////////////////////////////////////////
int subMenu()
{
    int opcion;
    printf("1- Para modificar apellido\n");
    printf("2- Para modificar nombre\n");
    printf("3- Para modificar sexo\n");
    printf("4- Para modificar salario\n");
    printf("5- Para modificar fecha de ingreso\n");
    printf("6- Para modificar sector\n");
    printf("\nIngrese una opcion: ");
    fflush(stdin);
    scanf("%d",&opcion);
    return opcion;
}

/////////////////////////////////////////////////////////////////
void inicializarEmpleados(eEmpleado vec[], int tam)
{
    for(int i=0; i < tam; i++)
    {
        vec[i].isEmpty = 0;
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void inicializacion(eEmpleado vec[], int tam, eSector sectores[], int tamSectores, eMenu menu[], int tamMenu,eAlmuerzo vecAlmuerzo[],int tamAlmuerzo)
{
    inicializarEmpleados(vec,tam);
    eEmpleado listaEmp[10]=
        {{0, "Frias","Brenda", 'f', 30000, 24,12,1997,0, 1},
        {1, "Frias", "Rodolfo",'m', 22000,5,6,2018,1, 1},
        {2, "Paoli","Elia", 'f', 12000,9,12,2013,3, 1},
        {3, "Marquez","Juan", 'm', 34000,16,3,2002,0, 1},
        {4, "Barry","Allen", 'm', 15000,15,8,2011,3, 1},
        {5, "Watson","Ema", 'f', 22000,1,12,2008,2, 1},
        {6, "Gardel","Carlos", 'm', 33000,21,6,2015,2, 1},
        {7, "Aumada","Raul", 'm', 32000,12,7,2016,2, 1},
        {8, "Diaz","Alejo", 'm', 30000,7,3,2004,4, 1},
        {9, "Franco","Carla", 'f', 12000,1,11,2005,2, 1}};

    for (int i = 0; i < 10; i++)//copio los valores del hardcodeo en la estructura de empleado
    {
        vec[i] = listaEmp[i];
    }

   eSector listaSectores[]= {{0, "Sistemas"},{1, "RR HH"},{2,"Compras"},{3,"Ventas"},{4, "Legales"}};

    for (int i = 0; i < tamSectores; i++)//copio los valores del hardcodeo en la estructura de sectores
    {
        sectores[i] = listaSectores[i];
    }

    eMenu listaMenues[]= {{0, "Pizza", 100.00},{1, "Arroz", 30.25},{2, "Pollo", 60.25},{3, "Panchos", 25.50},{4, "Milanesa", 55.00},{5, "Ravioles", 40.30},{6, "Pescado", 55.00},{7, "Empanadas", 30.25},{8, "Hamburgesa", 25.55},{9, "Ensalada", 25.35}};


    for (int i = 0; i < tamMenu; i++)//copio los valores del hardcodeo en la estructura de menu
    {
        menu[i] = listaMenues[i];
    }

     inicializarAlmuerzos(vecAlmuerzo,tamAlmuerzo);
     eAlmuerzo listaAlmuerzo[]= {{1,5,1,12,12,1999,1},{2,4,2,3,3,2000,1}};
     for(int i = 0;i < 3; i++)//copio los valores del hardcodeo en la estructura de almuerzo
        {
            vecAlmuerzo[i]=listaAlmuerzo[i];
        }


}
///////////////////////////////////////////////////////////
int buscarLibre(eEmpleado vec[], int tam)
{

    int indice = -1;

    for(int i=0; i < tam; i++)
    {
        if(vec[i].isEmpty == 0)
        {
            indice = i;
            break;
        }
    }

    return indice;
}
///////////////////////////////////////////////////////////
int buscarEmpleado(eEmpleado vec[], int tam, int legajo)
{

    int indice = -1;

    for(int i=0; i < tam; i++)
    {
        if(vec[i].isEmpty == 1 && vec[i].legajo == legajo)
        {
            indice = i;
            break;
        }
    }

    return indice;
}
/////////////////////////////////////////////////////////////////////////////////
void obtenerSector(eSector sectores[], int tamSectores, int idSectorEmp, char descMostrar[])
{
    for(int i=0; i<=tamSectores; i++)
    {
        if(idSectorEmp == sectores[i].id)
        {
            strcpy(descMostrar,sectores[i].desc);
            break;
        }
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int altaEmpleado(eEmpleado vec[], int tam,eSector sec[],int tamSectores, int legajoMain)
{

    int indice;
    int altaOk=0;

    indice = buscarLibre(vec,tam);



    if(indice ==-1)
        {
            printf("\nNo hay lugar en el sistema\n");

        }
        else
            {
                vec[indice].legajo=legajoMain++;

                getString(vec[indice].nombre,"Ingrese el nombre: ","Error,largo del nombre invalido",2,51);

                getString(vec[indice].apellido,"Ingrese el apellido: ","Error,Largo del apellido invalido",2,51);


                getCharGenre(&vec[indice].sexo,"Ingrese el sexo: ","Error, debe ingresar F o M");


                getFloat(&vec[indice].sueldo,"Ingrese sueldo: ","Error sueldo invalido",1,200000);

                getInt(&vec[indice].fechaIn.dia,"Ingrese el dia de ingreso","Error, dia invalido",1,31);

                getInt(&vec[indice].fechaIn.mes,"Ingrese el mes de ingreso","Error, mes invalido",1,12);


                getInt(&vec[indice].fechaIn.anio,"Ingrese el anio de ingreso","Error, anio invalido",1900,2019);

                printf("\n 0-Sistemas   1-RRHH   2-Compras   3-Ventas   4-Legales\n");

                getInt(&vec[indice].idSector,"Ingrese el numero de sector: ","Error, sector invalido",0,4);

                vec[indice].isEmpty =1;

                printf("\nALTA EXITOSA\n");

                altaOk=1;

            }

            return altaOk;



}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bajaEmpleado(eEmpleado vec[], int tam,eSector sec[],int tamSec)
{
    int legajo;
    int indiceLeg;
    char confirma;

    printf("Ingrese legajo: ");
    scanf("%d",&legajo);

    indiceLeg=buscarEmpleado(vec,tam,legajo);


    if(indiceLeg==-1)
        {
            printf("\nError, no se encuentra el legajo en el sistema\n");

        }
        else
            {
                do
                    {
                        printf("\nel siguiente empleado se eliminara del sistema...\n");
                         mostrarEmpleado(sec,tamSec,vec,indiceLeg);
                        printf("Esta seguro que quiere cuntinuar? s/n: ");
                        fflush(stdin);
                        confirma=getche();
                        printf("\n");
                        system("pause");
                        if(tolower(confirma)=='n')
                        {
                        printf ("Baja cancelada!\n");
                            break;
                        }
                        else
                            {
                                vec[indiceLeg].isEmpty=-1;
                                printf("\nBaja empleado exitosa\n");
                            }
                    }while(confirma!='s');
            }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void modificarEmpleado(eEmpleado vec[], int tam,eSector vecSec[],int tamSectores)
{

    int legajo;
    int indice;
    char confirma;

    printf("Ingrese legajo: ");
    scanf("%d",&legajo);

    indice=buscarEmpleado(vec,tam,legajo);

    if(indice==-1)
        {
            printf("\nError, no se encuentra el legajo en el sistema\n");

        }else
            {
                do
                    {

                        printf("\nEs este el empleado que desea modificar?\n");
                        mostrarEmpleado(vecSec,tamSectores,vec,indice);
                        printf("Esta seguro que quiere cuntinuar? s/n: ");
                        fflush(stdin);
                        confirma=getche();
                        printf("\n");
                        system("pause");
                        if(tolower(confirma)=='n')
                        {
                        printf ("Modificacion cancelada!\n");
                            break;
                        }
                        else
                            {
                                switch(subMenu())
                                {
                                    case 1:
                                        getString(vec[indice].apellido,"Ingrese el apellido: ","Error,Largo del apellido invalido",2,51);
                                            break;

                                    case 2:
                                        getString(vec[indice].nombre,"Ingrese el nombre: ","Error,largo del nombre invalido",2,51);
                                            break;
                                    case 3:
                                        getCharGenre(&vec[indice].sexo,"Ingrese el sexo: ","Error, debe ingresar F o M");
                                            break;
                                    case 4:
                                        getFloat(&vec[indice].sueldo,"Ingrese sueldo: ","Error sueldo invalido",1,200000);
                                            break;
                                    case 5:
                                        getInt(&vec[indice].fechaIn.dia,"Ingrese el dia de ingreso","Error, dia invalido",1,31);

                                        getInt(&vec[indice].fechaIn.mes,"Ingrese el mes de ingreso","Error, mes invalido",1,12);

                                        getInt(&vec[indice].fechaIn.anio,"Ingrese el anio de ingreso","Error, anio invalido",1900,2019);
                                            break;
                                    case 6:
                                        printf("\n 0-Sistemas   1-RRHH   2-Compras   3-Ventas   4-Legales\n");

                                        getInt(&vec[indice].idSector,"Ingrese el numero de sector: ","Error, sector invalido",0,4);
                                            break;

                                    default:
                                        printf("\n Opcion invalida\n\n");
                                        system("pause");
                                            break;

                                }
                                printf("\nModificacion exitosa!!!\n");
                            }
                    }while(confirma!='s');
            }


}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mostrarEmpleado(eSector sectores[],int tamSectores, eEmpleado emp[], int i)
{
    char nombreSector[20];

    obtenerSector(sectores, tamSectores, emp[i].idSector, nombreSector);

    printf("%03d\t%s\t%s\t%c\t%.2f\t%02d/%02d/%d\t%s\n", emp[i].legajo, emp[i].apellido, emp[i].nombre, emp[i].sexo, emp[i].sueldo,emp[i].fechaIn.dia,emp[i].fechaIn.mes,emp[i].fechaIn.anio,nombreSector);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mostrarEmpleados(eSector sectores[], int tamSectores, eEmpleado vec[], int tam)
{
    int contador=0;
   printf("\nLegajo\tApelli.\tNombre\tSexo\tSueldo\t\tIngreso\t\tSector\n");

    for(int i=0; i < tam; i++)
    {
        if(vec[i].isEmpty == 1)
        {

            mostrarEmpleado(sectores,tamSectores,vec, i);
            contador++;
        }
    }
    if (contador==0)
    {
        printf ("No hay empleados que listar\n\n");
    }

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ordenarEmpleadosApellido(eEmpleado vec[], int tam)
{
    eEmpleado auxEmp;

    for(int i=0; i<tam-1; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if(strcmp(vec[i].apellido, vec[j].apellido)>0)//si las cadenas son iguales retornara 0, si la primera es mayor retornara un valor positivo y si es menor retornara un valor negativo.
            {
                auxEmp = vec[i];
                vec[i] = vec[j];
                vec[j] = auxEmp;
            }
        }
    }
    printf("\n-- Empleados ordenados exitosamente --\n\n");

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mostrarSector (eEmpleado vec[], int tam, eSector sec[], int tamSec)
{
    system("cls");

    for (int i=0;i<=tamSec;i++)
    {
        printf ("Sector: %s\n\n", sec[i].desc);
        for (int j=0;j<tam;j++)
        {
            if((vec[j].idSector==sec[i].id) && vec[j].isEmpty==1)
            {
                mostrarEmpleado(sec,tamSec,vec, j);
            }

        }
    }

    printf ("\n\n");
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void inicializarAlmuerzos(eAlmuerzo vec[], int tamAlmuerzo)
{
    for(int i=0; i < tamAlmuerzo; i++)
    {
        vec[i].isEmpty = 0;
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int buscarLibreAlmuerzo(eAlmuerzo vec[], int tamAlmuerzo)
{

    int indice = -1;

    for(int i=0; i < tamAlmuerzo; i++)
    {
        if(vec[i].isEmpty == 0)
        {
            indice = i;
            break;
        }
    }

    return indice;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int buscarAlmuerzo(eAlmuerzo vec[], int tamAlmuerzo, int id)
{

    int indice = -1;

    for(int i=0; i < tamAlmuerzo; i++)
    {
        if(vec[i].isEmpty == 1 && vec[i].id == id)
        {
            indice = i;
            break;
        }
    }

    return indice;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
int altaAlmuerzo(eAlmuerzo vecAlmuerzo[],int tamAlmuerzo,eEmpleado vecEmpleado[], int tam,eSector sec[],int tamSectores, int legajoMain,eMenu vecMenu[],int tamMenu)
{


    int indice;
    int auxLegajo;
    int opcion;
    int altaOk=0;
    int indice2;

    indice=buscarLibreAlmuerzo(vecAlmuerzo,tamAlmuerzo);

    if(indice ==-1)
        {
            printf("\nNo hay lugar en el sistema\n");

        }
        else
            {

                vecAlmuerzo[indice].id=legajoMain++;

                mostrarEmpleados(sec,tamSectores,vecEmpleado,tam);
                getInt(&auxLegajo,"\nIngrese su legajo","Error, legajo invalido",0,200);
                indice2=buscarEmpleado(vecEmpleado,tam,auxLegajo);
                if(vecEmpleado[indice2].isEmpty!=1)
                    {
                        printf("\nError,No se encuentra su legajo\n");

                    }
                else{

                vecAlmuerzo[indice].legajoEmp=auxLegajo;



                mostrarMenu(vecMenu,tamMenu);
                getInt(&opcion,"\nIngrese el ID de menu","Error, ID invalido",0,10);
                vecAlmuerzo[indice].idMenu=opcion;

                getInt(&vecAlmuerzo[indice].fechaAlmuerzo.dia,"Ingrese el dia: ","Error, dia invalido",1,31);

                getInt(&vecAlmuerzo[indice].fechaAlmuerzo.mes,"Ingrese el mes: ","Error, mes invalido",1,12);

                getInt(&vecAlmuerzo[indice].fechaAlmuerzo.anio,"Ingrese el anio: ","Error, anio invalido",1950,2050);

                 vecAlmuerzo[indice].isEmpty =1;


                printf("\nALTA EXITOSA\n");
                altaOk=1;



                }
            }



                return altaOk;


}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mostrarAlmuerzo(eAlmuerzo alm[],int i)
{


    printf("\n %d\t  %d\t  %d\t  %02d/%02d/%d\t\ ",alm[i].id,alm[i].idMenu,alm[i].legajoEmp,alm[i].fechaAlmuerzo.dia,alm[i].fechaAlmuerzo.mes,alm[i].fechaAlmuerzo.anio);
    printf("\n");

}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mostrarAlmuerzos(eAlmuerzo vecAlmuerzo[], int tamAlmuerzo)
{
    int contador = 0;
     printf("\n ID ALM ID MENU LEGAJO EMP   FECHA\n");

    for(int i=0; i < tamAlmuerzo; i++)
    {
        if(vecAlmuerzo[i].isEmpty == 1)
        {
            mostrarAlmuerzo(vecAlmuerzo,i);
            contador++;
        }
    }

    if( contador == 0)
    {
        printf("\n(!) No hay almuerzos que mostrar (!)\n");
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mostrarAlmuerzosDeUnEmpleado(eEmpleado vec[],int tam,eSector vecSectores[],int tamSectores,eAlmuerzo vecAlmuerzos[],int tamAlmuerzos)
{
    int contador = 0;
    int auxLegajo;
    int indice;
                getInt(&auxLegajo,"\nIngrese su legajo","Error, legajo invalido",0,200);
                indice=buscarEmpleado(vec,tam,auxLegajo);
                if(vec[indice].isEmpty!=1)
                    {
                        printf("\nError,No se encuentra su legajo\n");

                    }
                    else
                    {

                            printf("\n ID ALM ID MENU LEGAJO EMP   FECHA\n");

                            for(int i=0; i < tamAlmuerzos; i++)
                            {
                                if(vecAlmuerzos[i].isEmpty == 1 && vecAlmuerzos[i].legajoEmp ==auxLegajo)
                                {
                                    mostrarAlmuerzo(vecAlmuerzos,i);
                                    contador++;

                                }

                            }
                            printf("Este empleado tiene %d almuerzo/s",contador);



                    }

                    if(contador==0)
                        {
                            printf("\nEste empleado no tiene almuerzos");
                        }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////
void mostrarMenu(eMenu vecMenu[], int tamMenu)
{
    for ( int i = 0; i < tamMenu; i++ )
    {
        printf("\n%d) %s %.2f", vecMenu[i].id, vecMenu[i].desc, vecMenu[i].importe);
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////
int menuDeInformes()
{
    int opcion;
    printf("\n1- Mostrar que cantidad hay de empleados\n");
    printf("2- Mostrar empleados por sueldo mas alto\n");
    printf("3- Seleccionar un sector y mostrar cuantos empleados tiene\n");
    printf("4- Mostrar la recaudacion de almuerzos\n");
    printf("5- Mostrar el menu mas pedido\n");
    printf("6- Regresar\n");

    fflush(stdin);
    printf("\nIngrese una opcion: ");
    scanf("%d",&opcion);

    return opcion;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
int empleadosDadosDeAlta(eEmpleado vec[],int tam)
{
    int contador=0;
    for(int i=0; i < tam; i++)
    {
        if(vec[i].isEmpty == 1)
        {
            contador=contador+1;

        }

    }

    return contador;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////

void ordenarEmpleadosPorSueldo(eEmpleado vec[],int tam)
{
    eEmpleado auxEmp;

    for(int i=0; i<tam-1; i++)
    {
        for(int j=i+1; j<tam; j++)
        {
            if(vec[i].sueldo < vec[j].sueldo)
            {
                auxEmp = vec[i];
                vec[i] = vec[j];
                vec[j] = auxEmp;
            }
        }
    }

}

///////////////////////////////////////////////////////////////////////////////////

int cuantosEmpleadosTieneEsteSector(eEmpleado vec[],int tam)
{
    int opcion;
    int contador=0;

    printf("\n 0-Sistemas   1-RRHH   2-Compras   3-Ventas   4-Legales\n");
    getInt(&opcion,"Ingrese un sector","Error, sector invalido",0,4);



    for(int i=0; i < tam; i++)
    {
        if(vec[i].idSector == opcion && vec[i].isEmpty ==1)
        {
            contador=contador+1;

        }

    }

    return contador;
}

///////////////////////////////////////////////////////////////////////////////////////////////

int recaudacionAlmuerzos(eAlmuerzo vecAlmuerzo[],int tamAlmuerzo,eMenu vecMenu[],int tamMenu)
{
    float acumulador=0;
    int idMenu;
    for(int i=0; i < tamAlmuerzo; i++)
    {
        if(vecAlmuerzo[i].isEmpty == 1)
        {
            idMenu=vecAlmuerzo[i].idMenu;
            for(int j=0; j< tamMenu;j++)
                {
                    if(idMenu== vecMenu[j].id)
                        {
                            acumulador=acumulador+vecMenu[j].importe;

                        }
                }
        }
    }
    return acumulador;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

