#ifndef socio_H_INCLUIDA//Para evitar que el compilador tire error por incluir varias veces la misma biblioteca del usuario.
#define socio_H_INCLUIDA
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <conio.h>
#include <ctype.h>

typedef struct
{
    int dia;
    int mes;
    int anio;
} eFecha;


typedef struct
{
    int codigoAutor;
    char apellido[31];
    char nombre[31];

    int isEmpty;

} eAutores;

typedef struct
{
    int codigoLibro;
    char titulo[51];
    int idCodigoAutor;
    int isEmpty;

} eLibros;


typedef struct
{
    int codigoSocio;
    char apellido[31];
    char nombre[31];
    char sexo;
    char telefono[31];
    char eMail[31];
    eFecha fechaAsociado;

    int isEmpty;

} eSocios;


typedef struct
{
    int codigoPrestamo;
    int idCodigoLibro;
    int idCodigoSocio;
    eFecha fechaPrestamo;
    int isEmpty;

} ePrestamos;

//FUNCIONES OTRAS//
///////////////////////////////////////////////////////////////////////
/** \brief Muestra el menu principal y captura una opcion.
 *
 * \return char opcion ingresada por el usuario.
 *
 */
char menuSocios();

/** \brief Muestra un submenu para modificar un socio y
 *         captura la opcion ingresada.
 *
 * \return int opcion ingresada por el usuario.
 *
 */
int subMenuModificar();

/** \brief Cambia el primer caracter a mayuscula de la estructua eSocios.
 *
 * \param vec vector de la estructura eSocios.
 * \param tam tama�o de la estructura.
 * \return void
 *
 */
void toUpperFirstLetter(eSocios vec[],int tam,int position);
//////////////////////////////////////////////////////////////////////


//FUNCIONES SOCIOS//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/** \brief Inicializa todas las estructuras y carga todos sus hardcodeos.
 *
 * \param vec vector de la estructura eSocios a ser inicializada y cargada.
 * \param tam tama�o de la estructura eSocios.
 * \param vecAutores vector de la estructura eAutores a ser inicializada y cargada.
 * \param tamAutores tama�o de la estructura eAutores.
 * \param vecLibros vector de la estructura eLibros a ser inicializada y cargada.
 * \param tamLibros tama�o de la estructura eLibros.
 * \param vecPrestamos vector de la estructura ePrestamos a ser inicializada y cargada.
 * \param tamPrestamos tama�o de la estructura ePrestamos.
 * \return void.
 *
 */
void inicializacion(eSocios vec[], int tam, eAutores vecAutores[], int tamAutores, eLibros vecLibros[], int tamLibros,ePrestamos vecPrestamos[],int tamPrestamos);

/** \brief recorre la estructura eSocios y si encuentra en el campo (isEmpty) una posicion
 *         que este ocupada retorna (1),si no encuentra una posicion ocupada retornara (0).
 *
 * \param vecSocios vector de la estructura eSocios (estructura a ser recorrida).
 * \param tam tama�o de la estructura eSocios.
 * \return int oneE (1) si un elemento (isEmpty=0) o (0) si todos los elementos del vector son(isEmpty=1).
 *
 */
int oneSocio(eSocios vecSocios[],int tam);

/** \brief Inicializa todos los elementos del vector de la estructura eSocios en el campo (isEmpty) con 1,
 *         para indicar que estan vacios y pueden ser cargados.
 *
 * \param vecSocios vector de la estructura eSocios a ser inicializado.
 * \param tam tama�o del vector de la estructura eSocios.
 * \return void.
 *
 */
void initSocios(eSocios vecSocios[],int tam);

/** \brief Busca una posicion "libre" en el vector de la estructura eSocios,
 *         si en el campo (isEmpty=1) retornara esa posicion del vector, si no encuentra
 *         una posicion "libre" retornara (-1) para luego indicar que no hay mas posiciones "libres".
 *
 * \param vecSocios vector de la estructura eSocios donde buscara una posicion "libre".
 * \param tam tama�o de la estructura eSocios.
 * \return int (index) posicion del vector en la que encontro "libre" o (-1) si no encontro "libre"
 *
 */
int searchFree(eSocios vecSocios[], int tam);

/** \brief Recorre la estructura eSocios y compara el parametro (codigoSocio) con el campo
 *         de la estructura codigoSocio si son iguales retornara (i) posicion del vector donde
 *         encontro la igualdad o (-1) si no hay igualdad esto indica que no existe ese codigoSocio en el vector.
 *
 * \param vecSocios vector de la estructura eSocios a ser recorrida.
 * \param tamSocios tama�o del vector.
 * \param codigoSocio entero a ser comparado con el campo codigoSocio de la estructura eSocios.
 * \return (i) si hay igualdad en los campos o (-1) si no la hay.
 *
 */
int buscarSocio(eSocios vecSocios[], int tamSocios, int codigoSocio);

/** \brief Muestra todos los campos de la estructura eSocios en el indice ingresado (i).
 *
 * \param listaSocios vector de la estructura eSocios.
 * \param i posicion del vector a ser mostrada.
 * \return void.
 *
 */
void mostrarSocio(eSocios listaSocios[], int i);

/** \brief Muestra todas las posiciones del vector eSocios que esten "ocupados" y su contenido.
 *
 * \param vec vector de la estructura eSocios.
 * \param tam tama�o de la estructura eSocios.
 * \return void.
 *
 */
void mostrarSocios(eSocios vec[], int tam);

/** \brief Carga los campos de la estructura eSocios del vector vec  con datos ingresados por el usuario,
 *         y recibe un codigo autoincremental (codigoMain) que es pasado al campo codigoSocio de la estructura eSocios.
 *
 * \param vec vector donde se guardara la estructura cargada.
 * \param tam tama�o del vector de la estructura.
 * \return int (altaOk) (1) si se realizo el alta o (0) si no se realizo.
 *
 */
int altaSocio(eSocios vec[], int tam, int codigoMain);


/** \brief Permite modificar un campo de la estructura seleccionado por el usuario.
 *
 * \param vec vector de la estructura eSocios.
 * \param tam tama�o del vector donde buscara al socio a ser modificado.
 * \return void.
 *
 */
void modificarSocio(eSocios vec[], int tam);


/** \brief Hace una baja logica en un socio seleccionado por el usuario si este existe remplaza
 *         el valor del campo (isEmpty) de la estructura eSocios por (1) para indicar que esta "libre".
 *
 * \param vec vector de la estructura eSocios donde buscara al socio y hara la baja.
 * \param tam tama�o de la estructura a ser recorrida.
 * \return
 *
 */
void bajaSocio(eSocios vec[], int tam);


/** \brief Ordena alfabeticamente el vector vec de la estructua eSocios en el campo de apellido
 *         con el metodo de "burbujeo".
 *
 * \param vec vector de la estructura eSocios a ser ordenada.
 * \param tam tama�o de la estructura.
 * \return void.
 *
 */
void ordenarSociosApellido(eSocios vec[], int tam);


/** \brief Compara la cantidad de prestamos de los socios y muestra los socios
 *         con m�s prestamos.
 *
 * \param vecSocios vector de la estructura eSocios, usada para mostrar los socios.
 * \param tamSocios tama�o de la estructura eSocios.
 * \param vecPrestamos vector de la estructura ePrestamos, usada para contar los prestamos.
 * \param tamPrestamos tama�o de la estructura ePrestamos.
 * \return void.
 *
 */
void socioConMasPrestamos(eSocios vecSocios[],int tamSocios, ePrestamos vecPrestamos[], int tamPrestamos);


/** \brief Muestra ordenado el vector soc de la estructura eSocios por el metodo de insercion.
 *
 * \param soc vector de la estructura eSocios (vector a ser ordenado y mostrado).
 * \param tam tama�o de la estructura eSocios.
 * \return void.
 *
 */
void listarYOrdenarPorInsercion(eSocios soc[], int tam);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//FUNCIONES PRESTAMOS//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/** \brief Inicializa todos los elementos del vector de la estructura ePrestamos en el campo (isEmpty) con 1,
 *         para indicar que estan vacios y pueden ser cargados.
 *
 * \param vecPrestamos vector de la estructura ePrestamos a ser inicializado.
 * \param tamPrestamos tama�o del vector de la estructura ePrestamos.
 * \return void.
 *
 */
void inicializarPrestamos(ePrestamos vecPrestamos[], int tamPrestamos);


/** \brief Carga los campos de la estructura ePrestamos del vector vecPrestamos  con datos ingresados por el usuario,
 *         y recibe un codigo autoincremental (codigoMain) que es pasado al campo codigoPrestamo de la estructura ePrestamos.
 *
 * \param vecPrestamos vector donde se guardara la estructura cargada, si este tiene espacio "libre".
 * \param tamPrestamos tama�o del vector la estructura ePrestamos.
 * \param vecSocios vector de la estructura eSocios, es usado para indicar el socio que dio de alta el prestamo.
 * \param tam tama�o del vector de la estructura eSocios a ser recorrido para la busqueda de ese socio.
 * \param vecAutor vector de la estructura autores, es usado para indicar el idDeAutor en el alta de un prestamo.
 * \param tamAutor tama�o del vector de la estructura eAutores a ser recorrido para la busqueda del autor.
 * \param codigoMain entero que es pasado para generar un codigoPrestamo autoincremental.
 * \param vecLibros vector de la estructura eLibros, es usada para indicar el id del libro que es prestado.
 * \param tamLibros tama�o del vector de la estructura eLibros a ser recorrido para la busqueda del libro a ser prestado.
 * \return int (altaOk) (1) si se realizo el alta o (0) si no se realizo.
 *
 */
int altaPrestamos(ePrestamos vecPrestamos[],int tamPrestamos,eSocios vecSocios[], int tam,eAutores vecAutor[],int tamAutor, int codigoMain,eLibros vecLibros[],int tamLibros);

/** \brief Busca una posicion "libre" en el vector de la estructura ePrestamos,
 *         si en el campo (isEmpty=1) retornara esa posicion del vector, si no encuentra
 *         una posicion "libre" retornara (-1) para luego indicar que no hay mas posiciones "libres".
 *
 * \param vecPrestamos vector de la estructura ePrestamos donde buscara una posicion "libre".
 * \param tamPrestamos tama�o de la estructura ePrestamos.
 * \return int (index) posicion del vector en la que encontro "libre" o (-1) si no encontro "libre"
 *
 */
int buscarLibrePrestamos(ePrestamos vecPrestamos[], int tamPrestamos);


/** \brief Muestra todos los campos de la estructura ePrestamos en el indice ingresado (i).
 *
 * \param vecPrestamos vector de la estructura ePrestamos.
 * \param i posicion del vector a ser mostrada.
 * \return void.
 *
 */
void mostrarPrestamo(ePrestamos vecPrestamos[],int i);


/** \brief Muestra todas las posiciones del vector ePrestamos que esten "ocupados" y su contenido.
 *
 * \param vecPrestamos vector de la estructura ePrestamos a ser mostrada.
 * \param tamPrestamos tama�o de la estructura ePrestamos.
 * \return void.
 *
 */
void mostrarPrestamos(ePrestamos vecPrestamos[], int tamPrestamos);


/** \brief Muestra todos los prestamos que dio de alta un socio.
 *
 * \param vecSocios vector de la estructura eSocios usado para mostrar los socios.
 * \param tam tama�o del vector de la estructura eSocios.
 * \param vecPrestamos vector de la estructura ePrestamos usado para recorrer los prestamos.
 * \param tamPrestamos tama�o del vector de la estructura ePrestamos.
 * \return void.
 *
 */
void mostrarPrestamosDeUnSocio(eSocios vecSocios[], int tam, ePrestamos vecPrestamos[], int tamPrestamos);

/** \brief Muestra todos los prestamos de un libro que dio de alta un socio.
 *
 * \param vecSocios vector de la estructura eSocios usado para mostrar los socios.
 * \param tam tama�o del vector de la estructura eSocios.
 * \param vecLibros vector de la estructura eLibros usada para mostrar todos los libros y asi
 *        el usuario escojer uno.
 * \param tamLibros tama�o del vector de la estructura eLibros.
 * \param vecPrestamos vector de la estructura ePrestamos usado para comparar en el campo idCodigoLibro
 *        si es igual al aux libro.
 * \param tamPrestamos tama�o del vector de la estructura ePrestamos.
 * \return void.
 *
 */
void mostrarPrestamosDeUnLibro(eSocios vecSocios[], int tam, eLibros vecLibros[], int tamLibros, ePrestamos vecPrestamos[], int tamPrestamos);


/** \brief El usuario ingresa una fecha y si en esa fecha hay prestamos estos son mostrados.
 *
 * \param lib vector de la estructura eLibros usado para mostrar los libros prestados en esa fecha.
 * \param tam tama�o del vector de la estructura eLibros.
 * \param prest vector de la estructura ePrestamos es usado para recorrer los prestamos y comparar en el
 *        campo (isEmpty) == 0 esto indica que existe un prestamo en esa posicion del vector y lo muestra.
 * \param tam2 tama�o del vector de la estructura ePrestamos.
 * \return void.
 *
 */
void  mostrarPrestamosDeUnaFecha(eLibros lib[], int tam, ePrestamos prest[], int tam2);


/** \brief El usuario ingresa una fecha y si en esa fecha hay prestamos los socios que los realizaron
 *         son mostrados.
 * \param vecSocios vector de la estructura eSocios usado para mostrar los socios que hicieron prestamos
 *        en la fecha ingresada.
 * \param tamSocios tama�o del vector de la estructura eSocios.
 *
 * \param tamPrestamos vector de la estructura ePrestamos es usado para recorrer los prestamos y comparar en el
 *        campo (isEmpty) == 0 esto indica que existe un prestamo en esa posicion del vector y lo muestra.
 * \param tamPrestamos tama�o del vector de la estructura ePrestamos.
 * \return void.
 *
 */
void mostrarPrestamosDeUnaFechaSocios(eSocios vecSocios[],int tamSocios,ePrestamos vecPrestamos[],int tamPrestamos);


/** \brief Es usado para contar la cantidad de prestamos total y diarios.
 *
 * \param prest vector de la estructura ePrestamos es usado para comprobar que el prestamo exista
 *        esto lo hace con el campo (isEmpty)== 0 de la estructura si este existe es sumado.
 * \param tam tama�o del vector de la estructura ePrestamos, vector a ser recorrido.
 * \param contadorDePrestamos tipo flotante puntero usado como contador de la cantidad de prestamos.
 * \param contadorDias tipo entero puntero usado como contador de la cantidad de dias.
 * \return void.
 *
 */
void obtenerPrestTotalYDiario(ePrestamos prest[], int tam, float* contadorDePrestamos, int* contadorDias);


/** \brief Es usado para mostrar los prestamos totales y diarios contiene a la funcion
 *         obtenerPrestTotalYDiario para realizar esto.
 *
 * \param prest vector de la estructura ePrestamos vector a ser recorrido.
 * \param tam tama�o del vector de la estructura ePrestamos.
 * \return void.
 *
 */
void prestamosTotalesyDiarios (ePrestamos prest[], int tam);


/** \brief Es usado para mostrar los dias que no superan el promedio, es calculado con la funcion
 *         obtenerPrestTotalYDiario.
 * \param prest vector de la estructura ePrestamos es usado para comprobar la existencia del prestamo.
 * \param tam tama�o del vector de la estructura ePrestamos a ser recorrido.
 * \return
 *
 */
void promedioNoSuperado (ePrestamos prest[], int tam);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


//FUNCIONES LIBROS//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/** \brief Es usado para mostrar los campos de la estructura eLibros en una posicion
 *         del vector vecLibros si este esta ocupado.
 *
 * \param vecLibros vector de la estructura eLibros usado para mostrar los campos del libro.
 * \param i es usado para indicar la posicion del vector a ser mostrada.
 * \return void.
 *
 */
void mostrarLibro(eLibros vecLibros[], int i);

/** \brief es usado para mostrar todos los libros que esten "ocupados", su campo (isEmpty)==0,
 *         usando la funcion mostrarLibro.
 *
 * \param vecLibros vector de la estructura eLibros.
 * \param tamLibros tama�o del vector de la estructura eLibros a ser recorrida.
 * \return void.
 *
 */
void mostrarLibros(eLibros vecLibros[], int tamLibros);

/** \brief Calcula cual es el libro menos prestado y lo muestra.
 *
 * \param vecLibros vector de la estructura eLibros usado para comprobar que el libro exista.
 * \param tamLibros tama�o del vector de la estructura eLibros.
 * \param vecPrestamos vector de la estructura ePrestamos usada para recorrer todos los prestamos,
 *        contar los que esten de alta y comparar el idCodigoLibro para ver que sean iguales.
 * \param tamPrestamos tama�o del vector de la estructura ePrestamos a ser recorrido.
 * \return void.
 *
 */
void informarLibroMenosPrestado (eLibros vecLibros[],int tamLibros, ePrestamos vecPrestamos[], int tamPrestamos);

/** \brief Es usado para comprobar la existencia de un libro, el usuario ingresa el codigoLibro,
 *         y si este es igual al campo codigoLibro de la estructura eLibros y si el campo (isEmpty) es == 0
 * \param vecLibros vector de la estructura eLibros vector donde buscara ese libro.
 * \param tamLibros tama�o del vector de la estructura eLibros.
 * \param codigoLibro parametro ingresado por el usuario para comparar si el libro existe.
 * \return void.
 *
 */
int buscarLibro(eLibros vecLibros[], int tamLibros, int codigoLibro);


/** \brief Ordena los libros (intercambiando su posicion) de manera alfabeticamente
 *          descendiente por el campo (titulo) y los muestra.
 * \param lib vector de la estructura eLibros donde se realizara el ordenamiento.
 * \param tam_libros tama�o del vector de la estructura eLibros, vector a ser recorrido.
 * \return void.
 *
 */
void listarLibrosDescendiente(eLibros lib[], int tam_libros);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//FUNCIONES AUTORES//
//////////////////////////////////////////////////////////////////
/** \brief Muestra todos los elementos del vector de la estructura eAutores
 *         si estos en el campo (isEmpty) son == 0.
 *
 * \param vecAutores vector de la estructura eAutores a ser corrido y comparado.
 * \param tamAutores tama�o del vector de la estructura eAutores.
 * \return void.
 *
 */
void mostrarAutores(eAutores vecAutores[], int tamAutores);
/////////////////////////////////////////////////////////////////
#endif // socio_H_INCLUIDA

