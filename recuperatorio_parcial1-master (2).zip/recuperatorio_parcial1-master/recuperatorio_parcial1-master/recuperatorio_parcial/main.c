#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>


#include "input.h"
#include "socio.h"



#define TAM_SOCIOS 50
#define TAM_AUTORES 5
#define TAM_LIBROS 10
#define TAM_PRESTAMOS 100


int main()
{
    system("color 5E");
    char seguir = 's';
    char confirma;
    int oneE;



    int codigoIncremental=11;// es cargado con 11 porque ya hay hardcodeados 10 socios
    int banderaAlta=0;


    int banderaAlta2=0;
    int codigoIncremental2=11;// es cargado con 11 porque ya hay hardcodeados 10 prestamos

    eSocios vecSocios[TAM_SOCIOS];
    eAutores vecAutores[TAM_AUTORES];
    eLibros vecLibros[TAM_LIBROS];
    ePrestamos vecPrestamos[TAM_PRESTAMOS];


    inicializacion(vecSocios,TAM_SOCIOS,vecAutores,TAM_AUTORES,vecLibros,TAM_LIBROS,vecPrestamos,TAM_PRESTAMOS);





        do
        {
            oneE=oneSocio(vecSocios,TAM_SOCIOS);//usado para comprobar si existe un socio

             switch(menuSocios())
            {
                case 'a':
                    printf("\nAlta socio\n");
                    banderaAlta=(altaSocio(vecSocios,TAM_SOCIOS,codigoIncremental));
                    system("pause");

                    if(banderaAlta==1){
                        codigoIncremental++;
                    }

                        break;
                case 'b':
                    if(oneE)
                        {
                            printf("\nModificar socio\n");

                            modificarSocio(vecSocios,TAM_SOCIOS);

                        }
                        else
                            {
                                printf("\nError, no hay socios para modificar.\n");
                                system("pause");
                            }


                        break;


                case 'c':

                    if(oneE)
                    {
                        printf("\nBaja socio\n");
                        bajaSocio(vecSocios,TAM_SOCIOS);
                    }
                    else
                    {
                        printf("\nError, no hay socios para dar de baja.\n");
                            system("pause");
                    }
                        break;

                case 'd':
                    if(oneE)
                        {
                            printf("\nListar socios\n");
                            ordenarSociosApellido(vecSocios,TAM_SOCIOS);
                            mostrarSocios(vecSocios,TAM_SOCIOS);
                                system("pause");
                        }
                        else
                            {
                                printf("\nError, no hay socios para listar.\n");
                                    system("pause");
                            }

                        break;
                case 'e':
                    printf("Listar libros");
                    mostrarLibros(vecLibros,TAM_LIBROS);
                    system("pause");

                        break;

                case 'f':
                    printf("listar autores");
                    mostrarAutores(vecAutores,TAM_AUTORES);
                    printf("\n");
                    system("pause");

                        break;

                case 'g':

                    if(oneE)
                        {
                            printf("Prestamos (alta)");
                            banderaAlta2=altaPrestamos(vecPrestamos,TAM_PRESTAMOS,vecSocios,TAM_SOCIOS,vecAutores,TAM_AUTORES,codigoIncremental2,vecLibros,TAM_LIBROS);

                                if(banderaAlta2==1)
                                {
                                    codigoIncremental2++;
                                }
                        }
                        else
                        {
                            printf("\nError, no hay socios para dar de alta un prestamo.\n");
                                system("pause");
                        }
                            break;


                case 'h':
                    prestamosTotalesyDiarios (vecPrestamos,TAM_PRESTAMOS);
                        system("pause");
                        break;

                case 'i':
                    promedioNoSuperado(vecPrestamos,TAM_PRESTAMOS);
                    system("pause");
                    break;



                 case 'j':
                    printf("Listar todos los socios que solicitaron el prestamo de un libro\n");
                    mostrarPrestamosDeUnLibro(vecSocios,TAM_SOCIOS,vecLibros,TAM_LIBROS,vecPrestamos,TAM_PRESTAMOS);
                    system("pause");

                    break;

                 case 'k':
                     printf("Mostrar prestamos de un socio determinado\n");

                     mostrarPrestamosDeUnSocio(vecSocios,TAM_SOCIOS,vecPrestamos,TAM_PRESTAMOS);
                     printf("\n");
                     system("pause");


                    break;

                 case 'l':
                    printf("Mostrar libro menos solicitado a prestamo\n");
                    informarLibroMenosPrestado(vecLibros,TAM_LIBROS,vecPrestamos,TAM_PRESTAMOS);
                    system("pause");
                    break;


                case 'm':
                    printf("Informar socio con mas prestamos\n");
                    socioConMasPrestamos(vecSocios,TAM_SOCIOS,vecPrestamos,TAM_PRESTAMOS);
                    system("pause");
                    break;


                case 'n':
                    printf("mostrar todos los libros prestados en una fecha\n");
                    mostrarPrestamosDeUnaFecha(vecLibros,TAM_LIBROS,vecPrestamos,TAM_PRESTAMOS);
                    printf("\n");
                    system("pause");
                    break;

                case 'o':
                    printf("mostrar socios que hicieron un prestamo en una fecha\n");
                    mostrarPrestamosDeUnaFechaSocios(vecSocios,TAM_SOCIOS,vecPrestamos,TAM_PRESTAMOS);
                    system("pause");
                    break;

                case 'p':
                    printf("Mostrar libros ordenados (descendente)");
                    listarLibrosDescendiente(vecLibros,TAM_LIBROS);
                    printf("\n");
                    system("pause");
                    break;

                case 'q':
                     printf("Listar todos los socios ordenados por apellido (ascendente)\n");
                     listarYOrdenarPorInsercion(vecSocios,TAM_SOCIOS);
                     system("pause");
                        break;


                    case 'r':
                    printf("\nConfirma la salida del programa s/n?: ");
                    fflush(stdin);
                    confirma = getche();

                    if( tolower(confirma) == 's')
                    {
                        printf("\n\n-- Programa finalizado --\n");
                        seguir = 'n';
                    }
                    break;



            default:
                printf("\n Opcion invalida\n\n");
                system("pause");
                break;
            }
        }
        while(seguir == 's');


    return 0;
}


////////////////////////////////////////////////////////////////////////////////////////////////
