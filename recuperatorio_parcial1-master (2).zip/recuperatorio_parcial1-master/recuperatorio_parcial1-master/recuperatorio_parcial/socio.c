#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>


#include "input.h"
#include "socio.h"

char menuSocios()
{


    char opcion;
    printf("a- Alta socio\n");
    printf("b- Modificar un socio\n");
    printf("c- Baja de socio\n");
    printf("d- Listar socios ordenados alfabeticamente\n");
    printf("e- Listar libros\n");
    printf("f- Listar autores\n");
    printf("g- Prestamos(alta)\n");
    printf("\n Informes\n\n");
    printf("h- Informar total general y promedio diario de prestamos\n");
    printf("i- Informar la cantidad de dias que el promedio no es superado\n");
    printf("j- Listar todos los socios que solicitaron el prestamo de un libro\n");
    printf("k- Listar todos los libros que fueron solicitados a prestamo de un socio\n");
    printf("l- Listar el/los libros menos solicitados en prestamos\n");
    printf("m- Listar el/los socios que realizaron mas solicitudes de prestamos\n");
    printf("n- Listar todos los libros solicitados en una fecha determinada\n");
    printf("o- Listar todos los socios que realizaron un prestamo en una fecha determinada\n");
    printf("p- Listar todos los libros ordenados por titulo(descendente)\n");
    printf("q- Listar todos los socios ordenados por apellido (ascendente)\n");
    printf("r- salir\n");

    fflush(stdin);
    printf("\nIngrese una opcion: ");
    scanf("%c",&opcion);

    return opcion;

}
/////////////////////////////////////////////////////////////////
int subMenuModificar()
{
    int opcion;
    printf("1- Para modificar apellido\n");
    printf("2- Para modificar nombre\n");
    printf("3- Para modificar sexo\n");
    printf("4- Para modificar teleofno\n");
    printf("5- Para modificar eMail\n");

    printf("\nIngrese una opcion: ");
    fflush(stdin);
    scanf("%d",&opcion);
    return opcion;
}
////////////////////////////////////////////////////////////
void initSocios(eSocios vecSocios[],int tam)
{
    int i;


    for( i=0;i<tam;i++)
    {
        vecSocios[i].isEmpty=1;

    }

}
/////////////////////////////////////////////////////////////////
void inicializarPrestamos(ePrestamos vecPrestamos[], int tamPrestamos)
{
    int i;

    for( i=0; i < tamPrestamos; i++)
    {
        vecPrestamos[i].isEmpty = 1;
    }
}
////////////////////////////////////////////////////////////
void inicializacion(eSocios vec[], int tam, eAutores vecAutores[], int tamAutores, eLibros vecLibros[], int tamLibros,ePrestamos vecPrestamos[],int tamPrestamos)
{
    initSocios(vec,tam);
    int i;


    eSocios listaSocios[] = {
    {1, "Frias","Brenda", 'F', "42203934","email@lala", {24,12,1997}, 0},
    {2, "Frias", "Rodolfo",'M', "42203933","frias@lala",{5,6,2018}, 0},
    {3, "Paoli","Elia", 'F', "42201211","paoli@lala",{9,12,2013}, 0},
    {4, "Marquez","Juan", 'M',"42203900","juan@lala",{16,3,2002}, 0},
    {5, "Barry","Allen", 'M', "42205050","barry@lala",{15,8,2011}, 0},
    {6, "Watson","Ema", 'F', "43433333","ema@lala",{1,12,2008}, 0},
    {7, "Gardel","Carlos", 'M', "11030346","carlos@lala",{21,6,2015}, 0},
    {8, "Aumada","Raul", 'M', "55542211","raul@lala",{12,7,2016}, 0},
    {9, "Diaz","Alejo", 'M', "42205959","alejo@lala",{7,3,2004}, 0},
    {10, "Franco","Carla", 'F', "43845512","carla@lala",{1,11,2005}, 0}
    };


    for (  i = 0; i < 10; i++)//copio los valores del hardcodeo en la estructura de eSocio.
    {
        vec[i] = listaSocios[i];
    }

   eAutores listaAutores[]= {{1, "Borges","Jorge",0},{2, "Alfo","Luis",0},{3, "Newt","Arlin",0},{4, "Roda","Ramiro",0},{5, "Fisco","Pedro",0}};

    for (  i = 0; i < 5; i++)//copio los valores del hardcodeo en la estructura de eAutores.
    {
        vecAutores[i] = listaAutores[i];
    }

    eLibros listaLibros[]= {{1, "La laguna",1,0},{2, "Cuentos para dormir",2,0},{3, "Casa embrujada", 3,0},{4, "Fisica cuantica",4,0},{5, "Matematicas",5,0},{6, "Leyendas urbanas", 2,0},{7, "Historia china", 4,0},{8, "Tu puedes cocinar",4,0},{9, "Juego de tronos",1,0},{10, "Ciencias naturales",3,0}};


    for ( i = 0; i < 10; i++)//copio los valores del hardcodeo en la estructura de eLibros.
    {
        vecLibros[i] = listaLibros[i];
    }

    inicializarPrestamos(vecPrestamos,tamPrestamos);
    ePrestamos listaPrestamos[] = {
                                    {1,1,1,{12,12,1999},0},{2,1,1,{1,1,2000},0},{3,3,6,{4,5,2000},0},
                                    {4,4,4,{12,12,1998},0},{5,5,5,{12,12,1997},0},{6,6,6,{3,1,1999},0},
                                    {7,7,7,{12,12,2000},0},{8,8,8,{18,2,1999},0},{9,9,9,{12,7,1999},0},
                                    {10,3,3,{12,12,1999},0}
                                  };
     for( i = 0;i <10; i++)//copio los valores del hardcodeo en la estructura de ePrestamos.
        {
            vecPrestamos[i]=listaPrestamos[i];
        }


}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

int searchFree(eSocios vecSocios[], int tam)
{

    int index = -1;
    int i;

    for( i=1; i < tam; i++)
    {
        if(vecSocios[i].isEmpty == 1)
        {
            index = i;
            break;
        }
    }

    return index;
}
///////////////////////////////////////////////////////////
int buscarSocio(eSocios vecSocios[], int tamSocios, int codigoSocio)
{

    int indice = -1;
    int i;


    for( i=0; i < tamSocios; i++)
    {
        if(vecSocios[i].isEmpty == 0 && vecSocios[i].codigoSocio == codigoSocio)
        {
            indice = i;
            break;
        }
    }

    return indice;
}


////////////////////////////////////////////////////////////////////////////////////////////
void mostrarSocio(eSocios listaSocios[], int i)
{

    printf("%03d\t%s\t%s\t%c\t%s\t%s\t%02d/%02d/%d\n", listaSocios[i].codigoSocio,listaSocios[i].apellido,listaSocios[i].nombre,listaSocios[i].sexo,listaSocios[i].telefono,listaSocios[i].eMail,listaSocios[i].fechaAsociado.dia,listaSocios[i].fechaAsociado.mes,listaSocios[i].fechaAsociado.anio);
}
///////////////////////////////////////////////////////////////
void mostrarLibro(eLibros vecLibros[], int i)
{

    printf("%03d\t%d\t%s\t\n", vecLibros[i].codigoLibro,vecLibros[i].idCodigoAutor,vecLibros[i].titulo);
}
///////////////////////////////////////////////////////////////////////////////////////////
void mostrarSocios(eSocios vec[], int tam)
{
    int contador=0;
    int i;

   printf("\nCodigo\tApelli.\tNombre\tSexo\tTelefono\t\tEmail\tIngreso\t\n");

    for( i=0; i < tam; i++)
    {
        if(vec[i].isEmpty == 0)
        {

            mostrarSocio(vec,i);
            contador++;
        }
    }
    if (contador==0)
    {
        printf ("No hay socios que listar\n\n");
    }

}
/////////////////////////////////////////////////////////////////////////////////////////////////
int altaSocio(eSocios vec[], int tam, int codigoMain)
{

    int indice;
    int altaOk=0;

    indice = searchFree(vec,tam);



    if(indice ==-1)
        {
            printf("\nNo hay lugar en el sistema\n");

        }
        else
            {


                getString(vec[indice].nombre,"Ingrese el nombre: ","Error,largo del nombre invalido",2,31);

                getString(vec[indice].apellido,"Ingrese el apellido: ","Error,Largo del apellido invalido",2,31);


                getCharGenre(&vec[indice].sexo,"Ingrese el sexo: ","Error, debe ingresar F o M");


                getString(vec[indice].telefono,"Ingrese su telefono: ","Error telefono invalido",8,16);

                getString(vec[indice].eMail,"Ingrese su email: ","Error,largo del email invalido",2,31);

                getInt(&vec[indice].fechaAsociado.dia,"Ingrese el dia de ingreso","Error, dia invalido",1,31);

                getInt(&vec[indice].fechaAsociado.mes,"Ingrese el mes de ingreso","Error, mes invalido",1,12);


                getInt(&vec[indice].fechaAsociado.anio,"Ingrese el anio de ingreso","Error, anio invalido",1900,2019);



                vec[indice].codigoSocio=codigoMain;

                vec[indice].isEmpty=0;


                toUpperFirstLetter(vec,tam,indice);

                printf("\nALTA EXITOSA\n");

                altaOk=1;

            }

            return altaOk;



}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void modificarSocio(eSocios vec[], int tam)
{

    int codigo;
    int indice;
    char confirma;

    printf("Ingrese codigo de socio: ");
    scanf("%d",&codigo);

    indice=buscarSocio(vec,tam,codigo);

    if(indice==-1)
        {
            printf("\nError, no se encuentra este socio en el sistema\n");

        }else
            {
                do
                    {

                        printf("\nEs este el socio que desea modificar?\n");
                        mostrarSocio(vec,indice);
                        printf("Esta seguro que quiere cuntinuar? s/n: ");
                        fflush(stdin);
                        confirma=getche();
                        printf("\n");
                        system("pause");
                        if(tolower(confirma)=='n')
                        {
                        printf ("Modificacion cancelada!\n");
                            break;
                        }
                        else
                            {
                                switch(subMenuModificar())
                                {
                                    case 1:
                                        getString(vec[indice].apellido,"Ingrese el apellido: ","Error,Largo del apellido invalido",2,31);
                                            break;

                                    case 2:
                                        getString(vec[indice].nombre,"Ingrese el nombre: ","Error,largo del nombre invalido",2,31);
                                            break;
                                    case 3:
                                        getCharGenre(&vec[indice].sexo,"Ingrese el sexo: ","Error, debe ingresar F o M");
                                            break;
                                    case 4:
                                         getString(vec[indice].telefono,"Ingrese su telefono: ","Error telefono invalido",8,16);
                                            break;
                                    case 5:
                                        getString(vec[indice].eMail,"Ingrese Email: ","Error email invalido",1,31);


                                            break;


                                    default:
                                        printf("\n Opcion invalida\n\n");
                                        system("pause");
                                            break;

                                }
                                printf("\nModificacion exitosa!!!\n");
                            }
                    }while(confirma!='s');
            }


}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
void bajaSocio(eSocios vec[], int tam)
{
    int opcion;
    int indiceCod;
    int codigo;

    printf("Ingrese codigo de socio: ");
    scanf("%d",&codigo);

    indiceCod=buscarSocio(vec,tam,codigo);


    if(indiceCod!=-1)
        {
           printf("Esta seguro que desea eliminar al empleado | %s, %s | ?\n 1- Estoy seguro.\n 2- No, Regresar.\n Ingrese una opcion: ",vec[indiceCod].nombre,vec[indiceCod].apellido);
            scanf("%d",&opcion);


            switch(opcion)
            {
                case 1:
                    vec[indiceCod].isEmpty=1;
                    printf("\nBaja empleado exitosa!!!\n\n");
                        break;

                case 2:
                    printf("\nRegresando...\n\n");
                        break;

                default:
                    printf("\nError, no ingreso una opcion valida.\n\n");
                        break;
            }


        } else
                {
                    printf("No existe un socio con ese codigo.");
                    system("pause");
                }


}
////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ordenarSociosApellido(eSocios vec[], int tam)
{
    eSocios auxSoc;
    int i;
    int j;


    for( i=0; i<tam-1; i++)
    {
        for( j=i+1; j<tam; j++)
        {
            if(strcmp(vec[i].apellido, vec[j].apellido)>0)//si las cadenas son iguales retornara 0, si la primera es mayor retornara un valor positivo y si es menor retornara un valor negativo.
            {
                auxSoc = vec[i];
                vec[i] = vec[j];
                vec[j] = auxSoc;
            }
        }
    }
    printf("\n-- Socios ordenados exitosamente --\n\n");

}
///////////////////////////////////////////////////////////////////////////////////////////////////
void mostrarLibros(eLibros vecLibros[], int tamLibros)
{
    int i;

   printf("\nCodLib\tCodAutor.\tTitulo Libro\n");
    for ( i = 0; i < tamLibros; i++ )
    {
        printf("\n  %d         %d         %s", vecLibros[i].codigoLibro, vecLibros[i].idCodigoAutor, vecLibros[i].titulo);
    }
    printf("\n");
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
int altaPrestamos(ePrestamos vecPrestamos[],int tamPrestamos,eSocios vecSocios[], int tam,eAutores vecAutor[],int tamAutor, int codigoMain,eLibros vecLibros[],int tamLibros)
{


    int indice;
    int auxCodigo;
    int opcion;
    int altaOk=0;
    int indice2;

    indice=buscarLibrePrestamos(vecPrestamos,tamPrestamos);

    if(indice ==-1)
        {
            printf("\nNo hay lugar en el sistema\n");

        }
        else
            {

                vecPrestamos[indice].codigoPrestamo=codigoMain;

                mostrarSocios(vecSocios,tam);
                getInt(&auxCodigo,"\nIngrese su codigo","Error, legajo invalido",0,200);
                indice2=buscarSocio(vecSocios,tam,auxCodigo);
                if(vecSocios[indice2].isEmpty!=0)
                    {
                        printf("\nError,No se encuentra\n");

                    }
                else{

                vecPrestamos[indice].idCodigoSocio=vecSocios[indice2].codigoSocio;




                mostrarLibros(vecLibros,tamLibros);
                getInt(&opcion,"\nIngrese el ID de libro","Error, ID invalido",1,10);
                vecPrestamos[indice].idCodigoLibro=opcion;

                getInt(&vecPrestamos[indice].fechaPrestamo.dia,"Ingrese el dia: ","Error, dia invalido",1,31);

                getInt(&vecPrestamos[indice].fechaPrestamo.mes,"Ingrese el mes: ","Error, mes invalido",1,12);

                getInt(&vecPrestamos[indice].fechaPrestamo.anio,"Ingrese el anio: ","Error, anio invalido",1950,2050);

                 vecPrestamos[indice].isEmpty =0;


                printf("\nALTA EXITOSA\n");
                altaOk=1;



                }
            }



                return altaOk;


}
int buscarLibrePrestamos(ePrestamos vecPrestamos[], int tamPrestamos)
{

    int indice = 0;
    int i;

    for( i=1; i < tamPrestamos; i++)
    {
        if(vecPrestamos[i].isEmpty == 1)
        {
            indice = i;
            break;
        }
    }

    return indice;
}
//////////////////////////////////////////////////////////////////////
void mostrarPrestamo(ePrestamos vecPrestamos[],int i)
{


    printf("\n %d\t  %d\t  %d\t  %02d/%02d/%d\t ",vecPrestamos[i].codigoPrestamo,vecPrestamos[i].idCodigoSocio,vecPrestamos[i].idCodigoLibro,vecPrestamos[i].fechaPrestamo.dia,vecPrestamos[i].fechaPrestamo.mes,vecPrestamos[i].fechaPrestamo.anio);
    printf("\n");

}
///////////////////////////////////////////////////////////////////////////////////////
void mostrarPrestamos(ePrestamos vecPrestamos[], int tamPrestamos)
{
    int contador = 0;
    int i;
     printf("\n ID PRES ID SOCIO ID LIBRO   FECHA\n");

    for( i=0; i < tamPrestamos; i++)
    {
        if(vecPrestamos[i].isEmpty == 0)
        {
            mostrarPrestamo(vecPrestamos,i);
            contador++;
        }
    }

    if( contador == 0)
    {
        printf("\n(!) No hay prestamos que mostrar (!)\n");
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void informarLibroMenosPrestado (eLibros vecLibros[],int tamLibros, ePrestamos vecPrestamos[], int tamPrestamos)
{

    int min = 0;
    int contador;
    int flag = 0;
    int i;
    int j;

    for (i = 0; i < tamLibros; i++) // recorro los libros
    {
        contador = 0;
        for (j = 0; j < tamPrestamos; j++) // recorro los prestamos por cada libro
        {
            if ( vecLibros[i].codigoLibro == vecPrestamos[j].idCodigoLibro && vecPrestamos[j].isEmpty == 0 && vecLibros[i].isEmpty == 0 ) // si encuentro uno de esos libros en el prestamo, verifico cuantos prestamos se hicieron para ese libro...
            {
                contador++;
            }
        }

        if ( flag == 0 && contador != 0) // con esto seteo un minimo a la primer cantidad de libros que le llegue
        {
            min = contador;
            flag = 1;
        }
        else if ( contador <= min && contador != 0)
        {
            min = contador;
        }

    }

    printf("\nCodigo del autor  Codigo del libro  titulo del libro\n\n");
    for ( i = 0; i < tamLibros; i++ ) // este for, recorre nuevamente todo, comparando el minimo encontrado
    {
        contador = 0;
        for (  j = 0; j < tamPrestamos; j++ )
        {
            if ( vecLibros[i].codigoLibro == vecPrestamos[j].idCodigoLibro && vecPrestamos[j].isEmpty == 0 && vecLibros[i].isEmpty == 0 ) // si encuentro uno de esos libros en el prestamo, verifico cuantos prestamos se hicieron para ese libro...
            {
                contador++;
            }
        }
        if (contador == min)
        {
            printf("%-16d  %-16d  %-51s \n", vecLibros[i].idCodigoAutor, vecLibros[i].codigoLibro, vecLibros[i].titulo);
        }
    }
}
/////////////////////////////////////////////////////////////////////////////////////////
void mostrarPrestamosDeUnSocio(eSocios vecSocios[], int tam, ePrestamos vecPrestamos[], int tamPrestamos)
{
    int j;
    int k;
    int socio;
    mostrarSocios(vecSocios,tam);
    getInt(&socio, "\nIngrese el codigo del socio que desea mostrar: ", "\nERROR, ese socio no existe...", 1, 200);

    printf("\nCodPres  CodSoc  Nombre      Apellido       CodLib  D/MM/AAAA\n\n");

    for(  j = 0; j < tamPrestamos; j++ ) // recorre los prestamos
    {
        //printf("%d prestcodigolibro %d\n", libro, prest[j].codigoLibro);
        if( socio == vecPrestamos[j].idCodigoSocio )
        {
            for( k = 0; k < tam; k++ ) // recorro los socios
            {
                if( vecSocios[k].isEmpty == 0 && vecPrestamos[j].isEmpty == 0 && vecSocios[socio-1].isEmpty == 0 && vecPrestamos[j].idCodigoSocio == vecSocios[k].codigoSocio )
                {
                    //printf("soc[%d].isEmpty = %d / prest[%d].isEmpty = %d / prest[%d].codigoEmpleado = %d / soc[%d].codigoDeSocio = %d\n\n", k, soc[k].isEmpty, j,prest[j].isEmpty,j, prest[j].codigoEmpleado, k, soc[k].codigoDeSocio);
                    printf("  %d       %d    %s        %s           %d      %2.2d/%.2d/%.4d\n", vecPrestamos[j].codigoPrestamo, vecSocios[k].codigoSocio, vecSocios[k].nombre, vecSocios[k].apellido, vecPrestamos[j].idCodigoLibro, vecPrestamos[j].fechaPrestamo.dia, vecPrestamos[j].fechaPrestamo.mes, vecPrestamos[j].fechaPrestamo.anio);
                }
            }
        }
    }
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
int buscarLibro(eLibros vecLibros[], int tamLibros, int codigoLibro)
{

    int indice = -1;
    int i;
    for( i=0; i < tamLibros; i++)
    {
        if(vecLibros[i].isEmpty == 0 && vecLibros[i].codigoLibro == codigoLibro)
        {
            indice = i;
            break;
        }
    }

    return indice;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void socioConMasPrestamos(eSocios vecSocios[],int tamSocios, ePrestamos vecPrestamos[], int tamPrestamos)
{

    int max = 0;
    int contador;
    int flag = 0;
    int i;
    int j;

    for ( i = 0; i < tamSocios; i++) // recorro los socios
    {
        contador = 0;
        for ( j = 0; j < tamPrestamos; j++) // recorro los prestamos por cada socio
        {
            if ( vecSocios[i].codigoSocio == vecPrestamos[j].idCodigoSocio && vecPrestamos[j].isEmpty == 0 && vecSocios[i].isEmpty == 0 ) // si encuentro uno de esos libros en el prestamo, verifico cuantos prestamos se hicieron para ese libro...
            {
                contador++;
            }
        }

        if ( flag == 0 && contador != 0) // con esto seteo un minimo a la primer cantidad de libros que le llegue
        {
            max = contador;
            flag = 1;
        }
        else if ( contador >= max && contador != 0)
        {
            max = contador;
        }

    }

    printf("\nCodigo de socio  Nombre           Apellido     Cantidad Prestamos  \n\n");
    for (  i = 0; i < tamSocios; i++ ) // este for, recorre nuevamente todo, comparando el minimo encontrado
    {
        contador = 0;
        for (  j = 0; j < tamPrestamos; j++ )
        {
            if ( vecSocios[i].codigoSocio == vecPrestamos[j].idCodigoSocio && vecPrestamos[j].isEmpty == 0 && vecSocios[i].isEmpty == 0 ) // si encuentro uno de esos libros en el prestamo, verifico cuantos prestamos se hicieron para ese libro...
            {
                contador++;
            }
        }
        if (contador == max)
        {
            printf("%-16d  %-15s  %-15s  %d \n", vecSocios[i].codigoSocio, vecSocios[i].nombre, vecSocios[i].apellido,contador);
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mostrarPrestamosDeUnLibro(eSocios vecSocios[], int tam, eLibros vecLibros[], int tamLibros, ePrestamos vecPrestamos[], int tamPrestamos)
{
    int libro;
    mostrarLibros(vecLibros,tamLibros);
    getInt(&libro, "\nIngrese el codigo del libro que desea mostrar: ", "\nERROR, ese libro no existe...", 1, 10);
    int j;
    int k;
    printf("\nCodPres  CodSoc  Nombre      Apellido       CodLib  D/MM/AAAA\n\n");

    for(  j = 0; j < tamPrestamos; j++ ) // recorre los prestamos
    {
        //printf("%d prestcodigolibro %d\n", libro, prest[j].codigoLibro);
        if( libro == vecPrestamos[j].idCodigoLibro)
        {
            for( k = 0; k < tam; k++ ) // recorro los socios
            {
                if( vecSocios[k].isEmpty == 0 && vecPrestamos[j].isEmpty == 0 && vecLibros[libro].isEmpty == 0 && vecPrestamos[j].idCodigoSocio == vecSocios[k].codigoSocio )
                {
                    //printf("soc[%d].isEmpty = %d / prest[%d].isEmpty = %d / prest[%d].codigoEmpleado = %d / soc[%d].codigoDeSocio = %d\n\n", k, soc[k].isEmpty, j,prest[j].isEmpty,j, prest[j].codigoEmpleado, k, soc[k].codigoDeSocio);
                    printf("  %d       %d    %s        %s           %d      %2.2d/%.2d/%.4d\n", vecPrestamos[j].codigoPrestamo, vecSocios[k].codigoSocio, vecSocios[k].nombre, vecSocios[k].apellido, vecPrestamos[j].idCodigoLibro, vecPrestamos[j].fechaPrestamo.dia, vecPrestamos[j].fechaPrestamo.mes, vecPrestamos[j].fechaPrestamo.anio);
                }
            }
        }
    }
}
/////////////////////////////////////////////////////////////////////////////////////////
void  mostrarPrestamosDeUnaFecha(eLibros lib[], int tam, ePrestamos prest[], int tam2)
{

    eFecha fechaAux;
    getInt(&fechaAux.dia, "Ingrese dia de ingreso: ", "ERROR: debe ser un numero entre 31 y 1. ", 1, 32);
    getInt(&fechaAux.mes, "Ingrese mes de ingreso: ", "ERROR: debe ser un numero entre 1 y 12. ", 1, 12);
    getInt(&fechaAux.anio, "Ingrese anio de ingreso: ", "ERROR: debe ser un numero entre 1900 y 2019. ", 1900, 2019);

    int j;
    int k;
    printf("\nCodigo del autor  Codigo del libro  titulo del libro\n\n");

    for(  j = 0; j < tam; j++ ) // recorre los libros
    {
        for( k = 0; k < tam2; k++ ) // recorro los prestamos
        {
            if( fechaAux.dia == prest[k].fechaPrestamo.dia && fechaAux.mes == prest[k].fechaPrestamo.mes && fechaAux.anio == prest[k].fechaPrestamo.anio)
            {
                if( lib[j].isEmpty == 0 && prest[k].isEmpty == 0 && prest[k].idCodigoLibro == lib[j].codigoLibro )
                {
                    printf("%-16d  %-16d  %-51s \n", lib[j].idCodigoAutor, lib[j].codigoLibro, lib[j].titulo);
                    break;

                }
            }
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////

void mostrarPrestamosDeUnaFechaSocios(eSocios vecSocios[],int tamSocios,ePrestamos vecPrestamos[],int tamPrestamos)
{
    int contador = 0;
    int auxDia;
    int auxMes;
    int auxAnio;
    int i;


    int auxSocio;

    eFecha auxFecha;
                getInt(&auxDia,"\nIngrese el dia","Error, dia invalido",1,31);

                getInt(&auxMes,"\nIngrese el mes","Error, mes invalido",1,12);
                getInt(&auxAnio,"\nIngrese el anio","Error, anio invalido",1900,2020);
                auxFecha.dia=auxDia;
                auxFecha.mes=auxMes;
                auxFecha.anio=auxAnio;







                            for( i=0; i < tamPrestamos; i++)
                            {
                                if(vecPrestamos[i].isEmpty == 0 && vecPrestamos[i].fechaPrestamo.dia ==auxFecha.dia)
                                {
                                    if(vecPrestamos[i].fechaPrestamo.mes==auxFecha.mes)
                                        {
                                            if(vecPrestamos[i].fechaPrestamo.anio==auxFecha.anio)
                                                {
                                                    auxSocio=vecPrestamos[i].idCodigoSocio;
                                                    auxSocio--;
                                                printf("\n ID PRES  COD SOC  ID LIBRO  FECHA \n");
                                                    mostrarPrestamo(vecPrestamos,i);

                                                printf("\nCodSoc  Apell.  Nombr.   Sexo     Telefono       EMail          Fecha\n");
                                                    mostrarSocio(vecSocios,auxSocio);



                                                }


                                                    contador++;
                                        }
                                }
                            }

                    if(contador==0)
                        {
                            printf("\nEsta fecha no tiene prestamos");
                        }

}
////////////////////////////////////////////////////////////////////////////////////////

int oneSocio(eSocios vecSocios[],int tam)
{

    int oneE=0;
    int i;

        for( i=0;i<tam;i++)
        {
            if(vecSocios[i].isEmpty==0)
            {
                oneE=1;
                    break;
            }
        }
    return oneE;
}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void toUpperFirstLetter(eSocios vec[],int tam,int position)
 {
    int i;

    vec[position].nombre[0]=toupper(vec[position].nombre[0]);

        for(i=1;i<31;i++)
        {
            vec[position].nombre[i]=tolower(vec[position].nombre[i]);
        }


    vec[position].apellido[0]=toupper(vec[position].apellido[0]);

        for(i=1;i<31;i++)
        {
            vec[position].apellido[i]=tolower(vec[position].apellido[i]);
        }

 }
 ////////////////////////////////////////////////////////////////////////////////////////////////

void obtenerPrestTotalYDiario(ePrestamos prest[], int tam, float* contadorDePrestamos, int* contadorDias)
{
    int contador;
    int i;
    int j;
    int k;

    for ( i = 0; i < 12; i++) // recorro todos los meses de un a�o
    {
        for ( j = 0; j < 31; j++) // recorro los 31 dias de un mes
        {
            contador = 0;
            for ( k = 0; k < tam; k++) // recorro los prestamos
            {
                if (prest[k].fechaPrestamo.dia == j+1 && prest[k].fechaPrestamo.mes == i+1 && prest[k].isEmpty == 0 )
                {
                    contador++;
                }
            }
            if (contador != 0)
            {
                *contadorDias = *contadorDias + 1;
            }

            *contadorDePrestamos = *contadorDePrestamos + contador;
        }
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void prestamosTotalesyDiarios (ePrestamos prest[], int tam)
{
    float promedio = 0;
    int contadorDeDias = 0;

    obtenerPrestTotalYDiario(prest,tam,&promedio,&contadorDeDias);

    printf("Prestamos totales = %.f \n", promedio);
    promedio = promedio / contadorDeDias;
    printf("Promedio diario = %.2f \n", promedio);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////
void promedioNoSuperado (ePrestamos prest[], int tam)
{
    int contador = 0;
    float promedio = 0;
    int contadorDias = 0;
    int i;
    int j;
    int k;

    obtenerPrestTotalYDiario(prest,tam,&promedio,&contadorDias);
    promedio = promedio / contadorDias;
    printf("(promedio diario: %.2f...)\n", promedio);
    contadorDias = 0;

    for ( i = 0; i < 12; i++) // recorro todos los meses de un a�o
    {

        for ( j = 0; j < 31; j++) // recorro los dias de un mes
        {
            contador = 0;
            for ( k = 0; k < tam; k++) // recorro los prestamos
            {
                if (prest[k].fechaPrestamo.dia == j+1 && prest[k].fechaPrestamo.mes == i+1 && prest[k].isEmpty == 0 )
                {
                    contador++;
                }
            }

            if (contador != 0 && contador < promedio)
            {
                contadorDias++;
            }
        }
    }

    printf("los dias que no superan al prestamo son: %d \n\n", contadorDias);
}
/////////////////////////////////////////////////////////////////////////////////////////
void listarLibrosDescendiente(eLibros lib[], int tam_libros)
{
    int flagNoEstaOrdenado = 1;
    eLibros auxLib[tam_libros];
    int i;
    while (flagNoEstaOrdenado == 1)
    {
        flagNoEstaOrdenado = 0;
        for ( i = 1; i < tam_libros; i++)
        {
            if (stricmp(lib[i].titulo, lib[i-1].titulo) > 0 && lib[i].isEmpty == 0 )
            {
                auxLib[0] = lib[i];
                lib[i] = lib[i-1];
                lib[i-1] = auxLib[0];
                flagNoEstaOrdenado = 1;
            }
        }
    }

    mostrarLibros(lib,tam_libros);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void listarYOrdenarPorInsercion(eSocios soc[], int tam)
{
    eSocios auxSoc[tam];
    int j;
    int i;
    for ( i = 1; i < tam; i++)
    {
        auxSoc[i] = soc[i];
        j = i - 1;

        while ( j >= 0 && stricmp(soc[j].apellido, auxSoc[i].apellido ) > 0 )
        {
            soc[j + 1] = soc[j];
            j--;
        }
        soc[j + 1] = auxSoc[i];
    }

    mostrarSocios(soc,tam);

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mostrarAutores(eAutores vecAutores[], int tamAutores)
{
    int i;
    printf("\nCodAut\tApelli.Autor\tNomb.Autor\n");

    for ( i = 0; i < tamAutores; i++ )
    {
        printf("\n %d\t %s\t \t%s\t", vecAutores[i].codigoAutor, vecAutores[i].apellido, vecAutores[i].nombre);
    }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
