#include <stdio.h>
#include <stdlib.h>
void getsChar(char* message,char* caracter);
int main()
{

    char nombre[20]= "sebastian";
    char sexo;
    char mensaje[]="ingrese sexo: ";

    char mensaje2[]="hola mundo";

    mostrarCadena(mensaje2);

    getsChar(mensaje,&sexo);//no necesito los corhetes para mostrar el string porq lo q necesita es el primer elemento
    printf("%c",sexo);

    return 0;
}


void mostrarCadena(char* cadena)
{
    while( *cadena !='\0')
        {
            printf("%c",*cadena);
            printf("\n");//para mostrar lo que escribe en cada iteracion y que no lo muestre junto
            cadena++;//dato curioso si no pongo esta linea imprime infinitas h
        }

        //for(int i=0;*(cadena+i) != '\0';i++)
          //  {
            //    printf("%c",*(cadena+i));
            //} que se yo algo hara

}
void getsChar(char* message,char* caracter)//no se le pondra corchetes  message porque es un puntero no se sabe si es vector o caracter
{
    printf("%s",message);
    fflush(stdin);
    scanf("%c",caracter);//le ingreso solo caracter sin* por q ya tengo al direcccion de memoria
}
