#include <stdio.h>
#include <stdlib.h>

struct alumno
{
    char nombre[20];
    int nota;

};
int main()
{
    alumno auxAlumno
    return 0;
}
