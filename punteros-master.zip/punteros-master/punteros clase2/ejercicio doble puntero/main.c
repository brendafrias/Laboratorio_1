#include <stdio.h>
#include <stdlib.h>

int main()
{
    system("color 5E");
    int a=5;
    int* pointerInt;
    int** pointerPointer;
    int resultado;
    pointerInt = &a;
    pointerPointer = &pointerInt;

    printf("\n Esto muestra el dato %d",a);
    printf("\n Esto accede a la direccion de memoria del dato %d",*pointerInt);
    printf("\n Esto accede a la direccion de memoria de la direccion de memoria del dato %d",**pointerPointer);


    printf("\n\n");
    printf("\n esto muestra la direccion de moria de a %p",&a);
    printf("\n esto muestra la direccion de moria de a %p",pointerInt);//ACCEDIENDO A pointerInt
    printf("\n esto muestra la direccion de moria de a %p",*pointerPointer);//ACCDEDIENDO A pointerPointer

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    printf("\nModificando punteros\n");

    resultado= *pointerInt + **pointerPointer;


    printf("\n Ahora pointerPointer vale %d",resultado);
    printf("\n");
    system("pause");

    return 0;
}
