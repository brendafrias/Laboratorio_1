#include <stdio.h>
#include <stdlib.h>

int main()
{
    system("color 5E");
    char letra= 'a';
    char palabra[]="hola";
    char* p=palabra;
    char* q;

    mostrarCadena(p);
    printf("\n\n");
    mostrarCadena2(p);


    return 0;
}
void mostrarCadena(char* punteroCadena)
{
    while(*punteroCadena != '\0')
        {
            printf("%c",*punteroCadena);
            printf("\n");
            printf("%p",punteroCadena);
            printf("\n");
            punteroCadena++;
        }

}

void mostrarCadena2(char* punteroCadena)
{
    int i=0;
    while(*(punteroCadena+i) != '\0')
        {
            printf("%c",*(punteroCadena+i));
            printf("\n");
            printf("%p",punteroCadena+i);
            printf("\n");
            i++;
        }
}
