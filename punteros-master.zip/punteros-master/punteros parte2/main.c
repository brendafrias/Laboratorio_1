#include <stdio.h>
#include <stdlib.h>
void mostrarVector(int vec[],int tamVec);//nomenclatura vectorial
void mostrarVector2(int vec[],int tamVec);//nomenclatura puntero
void mostrarVector3(int* vec,int tamVec);//nomenclatura puntero usa vector
void mostrarVector4(int* vec,int tamVec);//nomenclatura puntero usa puntero
int main()
{
    int vec[]={3,5,2,4,3};

    int* p;

    printf("%x \n",vec);//guarda la direccion de memoria del primer elemento del vector
    printf("%x \n",&vec[0]);
    printf("%x \n", *vec);//muestra ek primer elemento del vector
    printf("%d \n", *(vec+1));//incrementa el vector hacia la siguiente posicion


    //////////////////////////////////////////////////////////////////////////
    /////////////cree un for recorra todas la posicion del vector/////////////
    /////////////////////////////////////////////////////////////////////////

    printf("\n");
    for(int i=0;i<5;i++)
        {
            printf("%d\n",*(vec+i));
        }

    /////////////////////////////////////////////////////////////////////////////
    printf("\n");
    mostrarVector(vec,5);
    printf("\n");
    mostrarVector2(vec,5);
    printf("\n");
    mostrarVector3(vec,5);
    printf("\n");
    mostrarVector4(vec,5);
    return 0;
}


void mostrarVector(int vec[],int tamVec)//nomenclatura vectorial
{
    for(int i=0;i<tamVec;i++)
        {
            printf("%d\n",vec[i]);
        }

}
void mostrarVector2(int vec[],int tamVec)
{
    for(int i=0;i<tamVec;i++)
        {
            printf("%d \n",*(vec+i));
        }
}

void mostrarVector3(int* vec,int tamVec)
{
    for(int i=0;i<tamVec;i++)
        {

            printf("%d \n",vec[i]);
        }
}
////////////////////////////////////////////
//esta es la que se usara apartir de ahora
void mostrarVector4(int* vec,int tamVec)
{
    for(int i=0;i<tamVec;i++)
        {
            printf("%d \n",*(vec+i));
        }
}
