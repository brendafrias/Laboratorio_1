#include <stdio.h>
#include <stdlib.h>
int getInt(int* puntero, int veces, char* msj);

int main()
{
    int x;
    int flagX;
    char mensaje[20]={"Ingrese un numero\n"};

    flagX = getInt(&x, 3, mensaje);/*le paso la direccion de memoria de X a la funcion*/

    if(flagX == 1){
        printf("X vale %d \n",x);
    }
    else{
        printf("No se pudo cargar la variable");
    }

    return 0;
}

int getInt(int* puntero, int veces, char* msj)
{
    int num;
    int todoOk;
    int contador=1;

    printf("%s", msj);
    scanf("%d",&num);
-
    while(num<=0){
        printf("ERROR, Reingrese un numero positivo: ");
        scanf("%d",&num);
        contador++;

        if(contador==veces){
            todoOk=0;
            break;
        }
    }

    if(contador<3){
        *puntero=num;
        todoOk=1;
    }

    return todoOk;
}

