#include <stdio.h>
#include <stdlib.h>
void leerPuntero(int* p);
int main()
{
    int x = 10;
    int* p;
    p =&x;
    printf("%d \n",x);
    printf("%d \n",*p);//muestra lo que tiene la variable x
    printf("%x \n",&x);//muestra la direccion de memoria
    printf("%x \n",p);//muestra la direccion de memoria de la variable x
    //printf("%d \n",*(60fef8));

    ////////////////////////////////////////////////////////////////////////
    printf("\n");
    leerPuntero(&x);//parametro actual
    printf("\n");
    modificarPuntero(&x);
    printf("%d",x);//no se puede ingresar en la funcion por no reconose a la variable


    printf("\n");

    mostrarDireccionMemoria(&x);
    printf("\n");

    ///////////////////////////////////////////////////////////////////////////
    int z=10;
    int* r=&z;
    //int* q=r;

    int** q = &r; //puntero que guarda un puntero

    //printf("%d \n", *q);
    printf("muestra puntero guardado en puntero valor de variable \n");
    printf("%d \n",**q);



    return 0;
}


void leerPuntero(int* p)//paramametro formal
{
    printf("%d \n", *p);

}
void modificarPuntero(int* p)
{
    *p=38;

}
void mostrarDireccionMemoria(int* p)
{
     printf("direccion guarda en p: %x",p);

}

