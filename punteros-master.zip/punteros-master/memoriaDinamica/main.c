#include <stdio.h>
#include <stdlib.h>

//////////////////////////////
///////////APUNTES///////////
////////////////////////////
int main()
{
    int i;
    int* pNum;
    int* pAux;

    pNum= (int*)malloc(sizeof(int) * 5);//pNum= (int*)malloc(sizeof(int)); el *5 es agregado para conseguir un vector de 5

    if(pNum == NULL)
        {
            printf("\nNo queda memoria\n");
            system("pause");
            exit(1);

        }

    for( i=0;i<5;i++)
        {
            printf("\nIngrese un numero");
            scanf("%d",pNum+i);
            printf("\n");
            printf("el numero en esta posicion es: %d",*(pNum+i));//va entre parentecis para que afecte a los 2
        }

        pAux= (int*)realloc(pNum,sizeof(int)*10);
        if(pAux!= NULL)
            {
                pNum=pAux;
            }
        else{
            printf("No hay lugar vieja\n");
        }
        for( i=5;i<10;i++)
        {
            printf("\nIngrese un numero");
            scanf("%d",pNum+i);
            printf("\n");
            printf("el numero en esta posicion es: %d",*(pNum+i));//va entre parentecis para que afecte a los 2
        }


        for(i=0;i<10;i++)
            {
                printf("\n\n%d ",*(pNum+i));
            }

    //*pNum=10; lo use para el ejerccio anterior

    //printf("el numero es %d",*pNum); usado en el ejercicio anterior
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //void* realloc(*puntero,sizeof(int));//
    return 0;




}
