#include <stdio.h>
#include <stdlib.h>

int main()
{
    int* vec;
    int i;
    vec= (int*) calloc(10,sizeof(int)*10);
    for(i=0;i<10;i++)
        {
            printf("%d",*(vec+i));// esto mostrara como calloc le asigna 0 a todos los elementos del vector
        }
    return 0;
}
