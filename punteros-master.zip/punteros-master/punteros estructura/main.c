#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int dia;
    int mes;
    int anio;

}eFecha;

typedef struct
{
    int legajo;
    char nombre[20];
    char sexo;
    float sueldo;
    eFecha fechaIngreso;
}eEmpleado;


int main()
{
    system("color 5A");

    eEmpleado unEmpleado={1234,"juan",'m',30000,1,12,1999};
    eEmpleado otroEmpleado={2222,"ana",'f',31000,2,5,1997};
    eEmpleado* punteroEmpleado;
    punteroEmpleado= &unEmpleado;


    eEmpleado lista[]={unEmpleado,otroEmpleado};

    printf("Legajo: %d \n",unEmpleado.legajo);
    printf("Legajo: %d \n",punteroEmpleado->legajo);// se debe usar flecha -> para acceder al campo
    printf("Nombre: %s \n",punteroEmpleado->nombre);
    printf("Sexo: %c \n",punteroEmpleado->sexo);
    printf("Sueldo %.2f \n",punteroEmpleado->sueldo);
    printf("Legajo %d \n", *punteroEmpleado);//lo muestra porq los punteros muestran el primer elemento
    printf("Nombre: %s \n", *(punteroEmpleado+1));
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    ////estructuras dobles
    printf("\n \n");
    printf("Fecha: %d %d %d",punteroEmpleado->fechaIngreso.dia, punteroEmpleado->fechaIngreso.mes, punteroEmpleado->fechaIngreso.anio);

    printf("\n \n");
    printf("%s \n",(*punteroEmpleado).nombre);
    //////////////////////////////////////////////////////////////////////////////
    printf("\n \n");
    printf("%s \n",(lista +1)->nombre);
    printf("\n \n");
    /////////////////////////////////////////////////////////////////////////////
    for(int i=0;i<2;i++)//recorre el vector mostrando sus campos
        {
            printf("%s \n",(lista+i)->nombre);
            //si quiero mostrar todo agrego printsfs
            printf("legajo: %d , nombre: %s , sexo: %c, sueldo: %f",,,,,,);
        }
    return 0;
}
