int getString(char* pStr, char* msg, char*msgE);
int getInt (int *pNum, char* msg, char* msgE);
int getIntInRange (int *pNum,char *msg,char *msgE,int minimo,int maximo,int reintentos);
int getStringLetras (char* pStr, char* msg, char* msgE, int reintentos);
int getStringNumerosInt (char* pStr, char* msg, char* msgE,int reintentos);
int ordenarArrayMayorMenor (char* pArray, int len,int limit);
int showArrayInt(int* pArray,int len);
int showArrayChar(char* pArray,int len);
int isNumberInt (char* pStr);
int isLetter (char* pStr);

