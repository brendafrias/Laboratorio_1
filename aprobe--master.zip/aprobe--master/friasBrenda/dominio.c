#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "dominio.h"
#include "input.h"
#include "LinkedList.h"



/** \brief Asigna a la estructura  en el campo  un dato validando sus caracteres
 *
 * \param this Employee* estructura donde se guardara el nombre.
 * \param nombre char* parametro a ser validado.
 * \return todoOk int retornara 0 si no se logro asignar o 1 si se logro asignar
 *
 */
int dominio_setDominio(eDominio* this,char* dominio)
{
    int todoOk = 0;

        if( this != NULL && strlen(dominio) < 7 && strlen(dominio) > 5 )
        {
            strcpy(this->dominio, dominio);
            todoOk = 1;
        }

    return todoOk;
}

/** \brief Asigna a la estructura employee en el campo horasTrabajadas
 *         un dato validado entre 1 y 750.
 *
 * \param this Employee* estructura donde se guardara las horasTrabajadas.
 * \param horasTrabajadas int parametro a ser validado.
 * \return todoOk int retornara 0 si no se logro asignar o 1 si se logro asignar
 *
 */
int dominio_setAnio(eDominio* this,int anio)
{
    int todoOk = 0;

        if( this != NULL && anio >0 && anio <2060 )
        {
            this->anio = anio;
            todoOk = 1;
        }

    return todoOk;
}

/** \brief Asigna a la estructura employee en el campo sueldo un dato entero validado
 *         entre 1 y 100000.
 * \param this Employee* estructura donde se guardara el sueldo.
 * \param sueldo int parametro a ser validado.
 * \return todoOk int retornara 0 si no se logro asignar o 1 si se logro asignar
 *
 */
int dominio_setTipo(eDominio* this,char tipo)
{
    int todoOK = 1;

        if ( this != NULL )
            if(tipo == 'A' || tipo == 'M')
            {
                this->tipo = tipo;
                todoOK = 0;
            }

    return todoOK;
}


/** \brief Asigna a la estructura employee en el campo id un dato entero validado
 *         entre 1 y 100000.
 * \param this Employee* estructura donde se guardara el id.
 * \param id int parametro a ser validado.
 * \return todoOk int retornara 0 si no se logro asignar o 1 si se logro asignar
 *
 */
int dominio_setId(eDominio* this,int id)
{
    int todoOK = 1;

        if ( this != NULL && id > 0 && id < 100000 )
        {
            this->id = id;
            todoOK = 0;
        }

        return todoOK;
}

/** \brief Es usado para obtener el sueldo de un empleado, coprobando que
 *         el empleado no sea NULL o que su sueldo no sea NULL
 *
 * \param this Employee estructura a ser validada.
 * \param sueldo int entero a ser validado.
 * \return todoOk int retornara 0 si alguno de los campos son NULL o 1 si pudo obtener el dato.
 *
 */
int dominio_getTipo(eDominio* this,char* tipo)
{
    int todoOK = 0;

        if ( this != NULL || tipo != NULL)
        {
            todoOK = 1;
            *tipo = this->tipo;
        }

    return todoOK;
}

/** \brief Es usado para obtener el id de un empleado, coprobando que
 *         el empleado no sea NULL o que su id no sea NULL
 *
 * \param this Employee* estructura a ser validada.
 * \param id int* entero a ser validado.
 * \return todoOk int retornara 0 si alguno de los campos son NULL o 1 si pudo obtener el dato.
 *
 */
int dominio_getId(eDominio* this,int* id)
{
    int todoOK = 0;

        if ( this != NULL || id != NULL)
        {
            todoOK = 1;
            *id = this->id;
        }

    return todoOK;
}


int dominio_getDominio(eDominio* this,char* dominio)
{
    int todoOK = 0;

        if ( this != NULL || dominio != NULL)
        {
            todoOK = 1;
            *dominio = this->dominio;
        }

    return todoOK;
}

/** \brief Crea un nuevo empleado pidiendo memoria dinamica,si consigue memoria lo
 *         carga "vacio" en todos sus campos de la estructura y retorna la direccion de memoria de este.
 *
 * \param no tiene parametros.
 * \return newEmploye Employe* retornara NULL si no consige espacio o la direccion de memoria de donde consiguio.
 *
 */
eDominio* dominio_new()
{
    eDominio* newDominio = (eDominio*) malloc(sizeof(eDominio));

        if (newDominio != NULL)
        {
            newDominio->id = 0;

            strcpy(newDominio->dominio, " ");

            newDominio->anio = 0;

            newDominio->tipo = '0';
        }

    return newDominio;
}

/** \brief Carga datos a un nuevo empleado si lo logra retorna la direccion de memoria de este
 *         si no lo logra libera el espacio en memoria y carga al nuevo empleado con NULL.
 *
 * \param idStr char* es usado para asignar el id al nuevo empleado.
 * \param nombreStr char* es usado para asignar el nombre al nuevo empleado.
 * \param horasTrabajadasStr char* es usado para asignar el nombre al nuevo empleado.
 * \param sueldo char* es usado para asignar el sueldo al nuevo empleado.
 * \return newEmploye NULL si no se pudieron cargar los datos o la direccion de memoria del nuevo empleado.
 *
 */
eDominio* dominio_newParametros(char* idStr, char* dominioStr, char* anio, char* tipo)
{
    int todoOK = -1;

    eDominio* newDominio = dominio_new();

        if (newDominio != NULL)
        {
            dominio_setId(newDominio, atoi(idStr));

            dominio_setDominio(newDominio, dominioStr);

            dominio_setAnio(newDominio, atoi(anio));

            dominio_setTipo(newDominio, tipo);


            todoOK = 0;
    }

        if (todoOK == -1)
        {
            free(newDominio);

            newDominio = NULL;
        }

    return newDominio;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////
int controller_loadFromText(char* path , LinkedList* pArrayListDominio)
{
   int error;

    FILE* file;

    file = fopen(path, "r");


        error = parser_dominioFromText(file, pArrayListDominio);

    return error;

}
//////////////////////////////////////////////////////////////////////////////////////////////////////

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_dominioFromText(FILE* pFile , LinkedList* pArrayListDominio)
{
    int error = 1;
    int cant;
    char buffer[3][20];

    if (pFile != NULL)
    {
        fscanf(pFile, "%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2]); // LECTURA FANTASMA
        ll_clear(pArrayListDominio); // USADO PARA BORRAAR LA LISTA

        while( !feof(pFile) )
        {
            cant = fscanf(pFile, "%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2]);

            if ( cant < 3 )
            {
                if(feof(pFile))
                {
                    break;
                }
				else
                    {
                        printf("No leyo el ultimo registro");
                        break;
                    }
            }

            eDominio* auxDom = dominio_new();

                if (auxDom != NULL)
                {
                    auxDom = dominio_newParametros(buffer[0], buffer[1], buffer[2], buffer[3]);
                    ll_add(pArrayListDominio, auxDom);
                }
                else
                    {
                        printf("Error no se pudo cargar\n");
                        system("pause");
                        ll_clear(pArrayListDominio);
                        break;
                    }
        }


        error = 0;
        fclose(pFile);
    }

    return error;
}
///////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
int controller_ListDominio(LinkedList* pArrayListDominio)
{
    int error = 1;
    int len = ll_len(pArrayListDominio);
    eDominio* dom;
    dom= dominio_new();
    int i;


    if ( dom != NULL && len != 0)
    {
        printf("\n ID   // DOMINIO          // ANIO   // TIPO\n");

            for ( i = 0; i < len; i++)
            {

                dom = ll_get(pArrayListDominio, i);
                printf(" %04d    %-15s    %-16d     %-6c \n", dom->id, dom->dominio, dom->anio, dom->tipo);

            }

        error = 0;
    }


    return error;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int dominio_setTipoSegun(eDominio* pDominio)
{
    int todoOk=0;
    //eDominio* dom =pDominio;



               if( isdigit(pDominio->dominio[0]) == 1 )
                {
                    pDominio->tipo= 'M';
                    todoOk=1;
                }else
                {
                    pDominio->tipo='A';
                    todoOk=1;
                }






    return todoOk;

}

//////////////////////////////////////////////////////////////////////

int dominio_filter(void* pDominio)
{
    int retorno = -1;
    eDominio* Aux = pDominio;



    if(Aux->tipo == 'M')
    {
        retorno = 0; //
    }

    return retorno;
}


int dominio_filterM(void* pDominio)
{
    int retorno = -1;
    eDominio* Aux = pDominio;



    if(Aux->tipo == 'A')
    {
        retorno = 0; //
    }

    return retorno;
}


/////////////////////////////////////////////////////////////////////////////////

int generarArchivo(char* fileName,LinkedList* listaDominios)
{
    int retorno = -1;
    eDominio* pdom;
    int i;

    FILE* pFile = fopen(fileName,"w+");

    if(listaDominios != NULL && pFile != NULL)
    {
        fprintf(pFile, "id,dominio,anio,tipo\n");

        for (i=0;i<ll_len(listaDominios);i++)
        {
            pdom = ll_get(listaDominios, i);

            if(pdom != NULL)
            {
                fprintf (pFile,"%d,%s,%d,%d\n", pdom->id, pdom->dominio,
                                                pdom->anio, pdom->tipo);
            }
        }

        fclose(pFile);

        retorno = 1;
    }

    return retorno;
}

