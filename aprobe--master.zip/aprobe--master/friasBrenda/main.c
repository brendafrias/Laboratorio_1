#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"

#include "Dominio.h"

int main()
{
    system("color 4F");
    int opcion = 0;
    char nombreArch[20];


    LinkedList* listaDominios = ll_newLinkedList();
    LinkedList* listaFiltrada = ll_newLinkedList();

    LinkedList* listaFiltradaM = ll_newLinkedList();
    LinkedList* listaFiltradaA = ll_newLinkedList();



    do
    {

        system("cls");
        printf("-------  Menu: -------\n\n");
        printf("1. Cargar archivo automotor.\n");
        printf("2. Seteo del campo tipo.\n");
        printf("3. Filtro\n");
        printf("4. Generar archivos de salida\n");
        printf("5. Salir\n");

        printf("\nIngrese una opcion: ");
        scanf("%d", &opcion);

        switch(opcion)
        {
            case 1:
                    printf("ingrese nombre arch (en este caso ingrese datos.csv)");
                    scanf("%s",nombreArch);

                    //fgets(nombreArch,20,stdin);

                    if ( controller_loadFromText(nombreArch,listaDominios) )
                    {
                    printf("\nError al cargar los datos en modo texto.\n");
                    }
                    else
                        {
                            printf("\nSe han cargado los datos.\n");
                        }
                    controller_ListDominio(listaDominios);
                    system("pause");
                    break;

            case 2:


                    ll_map(listaDominios,dominio_setTipoSegun);
                    //dominio_setTipoSegun(listaDominios);
                     controller_ListDominio(listaDominios);

                    system("pause");
                    break;

            case 3:

                    listaFiltrada= ll_filter(listaDominios,dominio_filterM);
                    controller_ListDominio(listaFiltrada);
                    system("pause");
                    break;

            case 4:
                    listaFiltradaM= ll_filter(listaDominios,dominio_filter);
                    generarArchivo("auto.csv",listaFiltrada);
                    generarArchivo("moto.csv",listaFiltradaM);
                    printf("archivos generados");
                    system("pause");
                    break;

            case 5:
                printf("\nSaliendo.\n");
                ll_deleteLinkedList(listaDominios);
                    system("pause");
                    break;
        }


    } while( opcion != 5 );

    return 0;
}
