#ifndef dominio_H_INCLUDED
#define dominio_H_INCLUDED
typedef struct
{
    int id;
    char dominio[6];
    int anio;
    char tipo;
}eDominio;

#endif // employee_H_INCLUDED

int dominio_setTipoSegun(eDominio* pDominio);
int dominio_filter(void* pDominio);
int dominio_filterM(void* pDominio);
