#define FUNCIONES_H

float suma (float A, float B);
float resta(float A, float B);
float divicion(float A, float B);
float multiplicacion(float A, float B);
long long int factorial(float A);
