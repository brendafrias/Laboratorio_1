# tp_laboratorio_2
Este proyecto fue entregado fuera de fecha... me entere que habia que entregarlo en la fecha 13/5.
espero que sea revisado para poder corregir posibles errores desde ya muchas gracias.
