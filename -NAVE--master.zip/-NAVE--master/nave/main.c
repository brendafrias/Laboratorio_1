#include <stdio.h>
#include <stdlib.h>
#include<windows.h>

int main()
{
    printf("*");

    SetConsoleCursorPosition();
    return 0;
}
