#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    char nombre[10];
    int edad;
}aPersona;
int main()
{
    FILE *bin;
struct aPersona;
bin=fopen("bin.dat","wb");
printf("\nIngrese el nombre: ");
gets(aPersona.nombre);
printf("Ingrese la edad: ");
scanf("%d",&aPersona.edad);
fflush(stdin);
fwrite(&aPersona,sizeof(aPersona),1,bin);
fclose(bin);

}


    return 0;
}






//////////////////
/////apuntes/////
////////////////

/* archivos
hay dos tipos
-binarios(asociado a estructuras/interpretacion binaria)
-texto (interpretacion plana "texto plano")

parser




feof() va a retornar 1 o 0 1=si llego al final del archivo 0=si sigue recorriendo el archivo
ferror()La funci�n ferror comprueba el indicador de errores para el stream apuntado por stream.

Valor de retorno:
^
La funci�n ferror retorna un valor distinto a cero si y s�lo si el indicador de errores est� activado para stream.


rewind() va a revovinar el archivo "el se�alador"
fseek() la primera constante sera la posicion inicial del archivo , la otra sera la posicion donde estoy actual mente
y la ultima donde termina el archivo

ftell() permite saber la cantidad de bytes desde el comienzo hasta el final del archivo

int fscanf(FILE *fp,const char *formato[,direcci�n,...]); //hace lo mismo que scanf
la unica diferencia es q el dato es leido de un archivo y no introducido por teclado (lee cada linea)


int fprintf(FILE *fp,const char *formato[,argumento,...]);//igual a printf() muestra varias cosas en pantalla
la diferencia es que en fprintf() lo guardara en un archivo
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
FILE estructura

    typedef struct {
    int level; /* fill/empty level of buffer */
   // unsigned flags; /* File status flags */
   // char fd; /* File descriptor */
   // unsigned char hold; /* Ungetc char if no buffer */
   // int bsize; /* Buffer size */
   // unsigned char _FAR *buffer; /* Data transfer buffer */
   // unsigned char _FAR *curp; /* Current active pointer */
   // unsigned istemp; /* Temporary file indicator */
   // short token; /* Used for validity checking */
   // }FILE;
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//se hace puntero a file para identificar el archivo
//tendre que declarar la misma cantidad de punteros para archivos que tenga
//se declara asi FILE *pArchivo
///////////////FILE * fopen (const char *Nombre_de_archivo , const char *Modo)
//////////////esto retornara NULL si no lo pudo abrir o se abre
//Nombre_de_archivo: Es una cadena de caracteres que representa el archivo , es decir se
//pone la ruta y el nombre del archivo trabajar con ruta relativa para nombre de archivo
//*modo == modo[] apartir de ahora se usara *modo esto estara detallado en la pagina 7 del pdf (cuadro)



//w Abre un archivo de texto para operaciones de escritura //si no existe se crea uno vacio y si existe borra el archivo para poder escribir en el
//w+ Abre un archivo de texto para operaciones de escritura //si no existe se crea uno vacio y si existe borra el archivo para poder escribir en el

////////////////////////////////////////////////////////////////////////////////
//uso r+ y si retorna null capturo el error y si esta vacio uso w+ para crearlo/
////////////////////////////////////////////////////////////////////////////////
