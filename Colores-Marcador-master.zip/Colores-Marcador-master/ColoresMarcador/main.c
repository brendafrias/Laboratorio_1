#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>


int main()
{



    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_BLUE| BACKGROUND_GREEN);
    printf("hola mundo\n");

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | BACKGROUND_BLUE);
    printf("brenda frias\n");


    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_GREEN | BACKGROUND_RED);
    printf("probando colores\n");

    getch();

    return 0;
}
